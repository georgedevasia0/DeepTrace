(function () {
	'use strict';

	function getDefaultExportFromCjs (x) {
		return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
	}

	var browserPolyfill$1 = {exports: {}};

	var browserPolyfill = browserPolyfill$1.exports;

	var hasRequiredBrowserPolyfill;

	function requireBrowserPolyfill () {
		if (hasRequiredBrowserPolyfill) return browserPolyfill$1.exports;
		hasRequiredBrowserPolyfill = 1;
		(function (module, exports) {
			(function (global, factory) {
			  {
			    factory(module);
			  }
			})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : browserPolyfill, function (module) {

			  if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
			    throw new Error("This script should only be loaded in a browser extension.");
			  }
			  if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
			    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";

			    // Wrapping the bulk of this polyfill in a one-time-use function is a minor
			    // optimization for Firefox. Since Spidermonkey does not fully parse the
			    // contents of a function until the first time it's called, and since it will
			    // never actually need to be called, this allows the polyfill to be included
			    // in Firefox nearly for free.
			    const wrapAPIs = extensionAPIs => {
			      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
			      // at build time by replacing the following "include" with the content of the
			      // JSON file.
			      const apiMetadata = {
			        "alarms": {
			          "clear": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "clearAll": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "get": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "getAll": {
			            "minArgs": 0,
			            "maxArgs": 0
			          }
			        },
			        "bookmarks": {
			          "create": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "get": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getChildren": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getRecent": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getSubTree": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getTree": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "move": {
			            "minArgs": 2,
			            "maxArgs": 2
			          },
			          "remove": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "removeTree": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "search": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "update": {
			            "minArgs": 2,
			            "maxArgs": 2
			          }
			        },
			        "browserAction": {
			          "disable": {
			            "minArgs": 0,
			            "maxArgs": 1,
			            "fallbackToNoCallback": true
			          },
			          "enable": {
			            "minArgs": 0,
			            "maxArgs": 1,
			            "fallbackToNoCallback": true
			          },
			          "getBadgeBackgroundColor": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getBadgeText": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getPopup": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getTitle": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "openPopup": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "setBadgeBackgroundColor": {
			            "minArgs": 1,
			            "maxArgs": 1,
			            "fallbackToNoCallback": true
			          },
			          "setBadgeText": {
			            "minArgs": 1,
			            "maxArgs": 1,
			            "fallbackToNoCallback": true
			          },
			          "setIcon": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "setPopup": {
			            "minArgs": 1,
			            "maxArgs": 1,
			            "fallbackToNoCallback": true
			          },
			          "setTitle": {
			            "minArgs": 1,
			            "maxArgs": 1,
			            "fallbackToNoCallback": true
			          }
			        },
			        "browsingData": {
			          "remove": {
			            "minArgs": 2,
			            "maxArgs": 2
			          },
			          "removeCache": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "removeCookies": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "removeDownloads": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "removeFormData": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "removeHistory": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "removeLocalStorage": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "removePasswords": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "removePluginData": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "settings": {
			            "minArgs": 0,
			            "maxArgs": 0
			          }
			        },
			        "commands": {
			          "getAll": {
			            "minArgs": 0,
			            "maxArgs": 0
			          }
			        },
			        "contextMenus": {
			          "remove": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "removeAll": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "update": {
			            "minArgs": 2,
			            "maxArgs": 2
			          }
			        },
			        "cookies": {
			          "get": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getAll": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getAllCookieStores": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "remove": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "set": {
			            "minArgs": 1,
			            "maxArgs": 1
			          }
			        },
			        "devtools": {
			          "inspectedWindow": {
			            "eval": {
			              "minArgs": 1,
			              "maxArgs": 2,
			              "singleCallbackArg": false
			            }
			          },
			          "panels": {
			            "create": {
			              "minArgs": 3,
			              "maxArgs": 3,
			              "singleCallbackArg": true
			            },
			            "elements": {
			              "createSidebarPane": {
			                "minArgs": 1,
			                "maxArgs": 1
			              }
			            }
			          }
			        },
			        "downloads": {
			          "cancel": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "download": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "erase": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getFileIcon": {
			            "minArgs": 1,
			            "maxArgs": 2
			          },
			          "open": {
			            "minArgs": 1,
			            "maxArgs": 1,
			            "fallbackToNoCallback": true
			          },
			          "pause": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "removeFile": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "resume": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "search": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "show": {
			            "minArgs": 1,
			            "maxArgs": 1,
			            "fallbackToNoCallback": true
			          }
			        },
			        "extension": {
			          "isAllowedFileSchemeAccess": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "isAllowedIncognitoAccess": {
			            "minArgs": 0,
			            "maxArgs": 0
			          }
			        },
			        "history": {
			          "addUrl": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "deleteAll": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "deleteRange": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "deleteUrl": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getVisits": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "search": {
			            "minArgs": 1,
			            "maxArgs": 1
			          }
			        },
			        "i18n": {
			          "detectLanguage": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getAcceptLanguages": {
			            "minArgs": 0,
			            "maxArgs": 0
			          }
			        },
			        "identity": {
			          "launchWebAuthFlow": {
			            "minArgs": 1,
			            "maxArgs": 1
			          }
			        },
			        "idle": {
			          "queryState": {
			            "minArgs": 1,
			            "maxArgs": 1
			          }
			        },
			        "management": {
			          "get": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getAll": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "getSelf": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "setEnabled": {
			            "minArgs": 2,
			            "maxArgs": 2
			          },
			          "uninstallSelf": {
			            "minArgs": 0,
			            "maxArgs": 1
			          }
			        },
			        "notifications": {
			          "clear": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "create": {
			            "minArgs": 1,
			            "maxArgs": 2
			          },
			          "getAll": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "getPermissionLevel": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "update": {
			            "minArgs": 2,
			            "maxArgs": 2
			          }
			        },
			        "pageAction": {
			          "getPopup": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getTitle": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "hide": {
			            "minArgs": 1,
			            "maxArgs": 1,
			            "fallbackToNoCallback": true
			          },
			          "setIcon": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "setPopup": {
			            "minArgs": 1,
			            "maxArgs": 1,
			            "fallbackToNoCallback": true
			          },
			          "setTitle": {
			            "minArgs": 1,
			            "maxArgs": 1,
			            "fallbackToNoCallback": true
			          },
			          "show": {
			            "minArgs": 1,
			            "maxArgs": 1,
			            "fallbackToNoCallback": true
			          }
			        },
			        "permissions": {
			          "contains": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getAll": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "remove": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "request": {
			            "minArgs": 1,
			            "maxArgs": 1
			          }
			        },
			        "runtime": {
			          "getBackgroundPage": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "getPlatformInfo": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "openOptionsPage": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "requestUpdateCheck": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "sendMessage": {
			            "minArgs": 1,
			            "maxArgs": 3
			          },
			          "sendNativeMessage": {
			            "minArgs": 2,
			            "maxArgs": 2
			          },
			          "setUninstallURL": {
			            "minArgs": 1,
			            "maxArgs": 1
			          }
			        },
			        "sessions": {
			          "getDevices": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "getRecentlyClosed": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "restore": {
			            "minArgs": 0,
			            "maxArgs": 1
			          }
			        },
			        "storage": {
			          "local": {
			            "clear": {
			              "minArgs": 0,
			              "maxArgs": 0
			            },
			            "get": {
			              "minArgs": 0,
			              "maxArgs": 1
			            },
			            "getBytesInUse": {
			              "minArgs": 0,
			              "maxArgs": 1
			            },
			            "remove": {
			              "minArgs": 1,
			              "maxArgs": 1
			            },
			            "set": {
			              "minArgs": 1,
			              "maxArgs": 1
			            }
			          },
			          "managed": {
			            "get": {
			              "minArgs": 0,
			              "maxArgs": 1
			            },
			            "getBytesInUse": {
			              "minArgs": 0,
			              "maxArgs": 1
			            }
			          },
			          "sync": {
			            "clear": {
			              "minArgs": 0,
			              "maxArgs": 0
			            },
			            "get": {
			              "minArgs": 0,
			              "maxArgs": 1
			            },
			            "getBytesInUse": {
			              "minArgs": 0,
			              "maxArgs": 1
			            },
			            "remove": {
			              "minArgs": 1,
			              "maxArgs": 1
			            },
			            "set": {
			              "minArgs": 1,
			              "maxArgs": 1
			            }
			          }
			        },
			        "tabs": {
			          "captureVisibleTab": {
			            "minArgs": 0,
			            "maxArgs": 2
			          },
			          "create": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "detectLanguage": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "discard": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "duplicate": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "executeScript": {
			            "minArgs": 1,
			            "maxArgs": 2
			          },
			          "get": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getCurrent": {
			            "minArgs": 0,
			            "maxArgs": 0
			          },
			          "getZoom": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "getZoomSettings": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "goBack": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "goForward": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "highlight": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "insertCSS": {
			            "minArgs": 1,
			            "maxArgs": 2
			          },
			          "move": {
			            "minArgs": 2,
			            "maxArgs": 2
			          },
			          "query": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "reload": {
			            "minArgs": 0,
			            "maxArgs": 2
			          },
			          "remove": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "removeCSS": {
			            "minArgs": 1,
			            "maxArgs": 2
			          },
			          "sendMessage": {
			            "minArgs": 2,
			            "maxArgs": 3
			          },
			          "setZoom": {
			            "minArgs": 1,
			            "maxArgs": 2
			          },
			          "setZoomSettings": {
			            "minArgs": 1,
			            "maxArgs": 2
			          },
			          "update": {
			            "minArgs": 1,
			            "maxArgs": 2
			          }
			        },
			        "topSites": {
			          "get": {
			            "minArgs": 0,
			            "maxArgs": 0
			          }
			        },
			        "webNavigation": {
			          "getAllFrames": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "getFrame": {
			            "minArgs": 1,
			            "maxArgs": 1
			          }
			        },
			        "webRequest": {
			          "handlerBehaviorChanged": {
			            "minArgs": 0,
			            "maxArgs": 0
			          }
			        },
			        "windows": {
			          "create": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "get": {
			            "minArgs": 1,
			            "maxArgs": 2
			          },
			          "getAll": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "getCurrent": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "getLastFocused": {
			            "minArgs": 0,
			            "maxArgs": 1
			          },
			          "remove": {
			            "minArgs": 1,
			            "maxArgs": 1
			          },
			          "update": {
			            "minArgs": 2,
			            "maxArgs": 2
			          }
			        }
			      };
			      if (Object.keys(apiMetadata).length === 0) {
			        throw new Error("api-metadata.json has not been included in browser-polyfill");
			      }

			      /**
			       * A WeakMap subclass which creates and stores a value for any key which does
			       * not exist when accessed, but behaves exactly as an ordinary WeakMap
			       * otherwise.
			       *
			       * @param {function} createItem
			       *        A function which will be called in order to create the value for any
			       *        key which does not exist, the first time it is accessed. The
			       *        function receives, as its only argument, the key being created.
			       */
			      class DefaultWeakMap extends WeakMap {
			        constructor(createItem, items = undefined) {
			          super(items);
			          this.createItem = createItem;
			        }
			        get(key) {
			          if (!this.has(key)) {
			            this.set(key, this.createItem(key));
			          }
			          return super.get(key);
			        }
			      }

			      /**
			       * Returns true if the given object is an object with a `then` method, and can
			       * therefore be assumed to behave as a Promise.
			       *
			       * @param {*} value The value to test.
			       * @returns {boolean} True if the value is thenable.
			       */
			      const isThenable = value => {
			        return value && typeof value === "object" && typeof value.then === "function";
			      };

			      /**
			       * Creates and returns a function which, when called, will resolve or reject
			       * the given promise based on how it is called:
			       *
			       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
			       *   the promise is rejected with that value.
			       * - If the function is called with exactly one argument, the promise is
			       *   resolved to that value.
			       * - Otherwise, the promise is resolved to an array containing all of the
			       *   function's arguments.
			       *
			       * @param {object} promise
			       *        An object containing the resolution and rejection functions of a
			       *        promise.
			       * @param {function} promise.resolve
			       *        The promise's resolution function.
			       * @param {function} promise.reject
			       *        The promise's rejection function.
			       * @param {object} metadata
			       *        Metadata about the wrapped method which has created the callback.
			       * @param {boolean} metadata.singleCallbackArg
			       *        Whether or not the promise is resolved with only the first
			       *        argument of the callback, alternatively an array of all the
			       *        callback arguments is resolved. By default, if the callback
			       *        function is invoked with only a single argument, that will be
			       *        resolved to the promise, while all arguments will be resolved as
			       *        an array if multiple are given.
			       *
			       * @returns {function}
			       *        The generated callback function.
			       */
			      const makeCallback = (promise, metadata) => {
			        return (...callbackArgs) => {
			          if (extensionAPIs.runtime.lastError) {
			            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
			          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
			            promise.resolve(callbackArgs[0]);
			          } else {
			            promise.resolve(callbackArgs);
			          }
			        };
			      };
			      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";

			      /**
			       * Creates a wrapper function for a method with the given name and metadata.
			       *
			       * @param {string} name
			       *        The name of the method which is being wrapped.
			       * @param {object} metadata
			       *        Metadata about the method being wrapped.
			       * @param {integer} metadata.minArgs
			       *        The minimum number of arguments which must be passed to the
			       *        function. If called with fewer than this number of arguments, the
			       *        wrapper will raise an exception.
			       * @param {integer} metadata.maxArgs
			       *        The maximum number of arguments which may be passed to the
			       *        function. If called with more than this number of arguments, the
			       *        wrapper will raise an exception.
			       * @param {boolean} metadata.singleCallbackArg
			       *        Whether or not the promise is resolved with only the first
			       *        argument of the callback, alternatively an array of all the
			       *        callback arguments is resolved. By default, if the callback
			       *        function is invoked with only a single argument, that will be
			       *        resolved to the promise, while all arguments will be resolved as
			       *        an array if multiple are given.
			       *
			       * @returns {function(object, ...*)}
			       *       The generated wrapper function.
			       */
			      const wrapAsyncFunction = (name, metadata) => {
			        return function asyncFunctionWrapper(target, ...args) {
			          if (args.length < metadata.minArgs) {
			            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
			          }
			          if (args.length > metadata.maxArgs) {
			            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
			          }
			          return new Promise((resolve, reject) => {
			            if (metadata.fallbackToNoCallback) {
			              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
			              // and so the polyfill will try to call it with a callback first, and it will fallback
			              // to not passing the callback if the first call fails.
			              try {
			                target[name](...args, makeCallback({
			                  resolve,
			                  reject
			                }, metadata));
			              } catch (cbError) {
			                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
			                target[name](...args);

			                // Update the API method metadata, so that the next API calls will not try to
			                // use the unsupported callback anymore.
			                metadata.fallbackToNoCallback = false;
			                metadata.noCallback = true;
			                resolve();
			              }
			            } else if (metadata.noCallback) {
			              target[name](...args);
			              resolve();
			            } else {
			              target[name](...args, makeCallback({
			                resolve,
			                reject
			              }, metadata));
			            }
			          });
			        };
			      };

			      /**
			       * Wraps an existing method of the target object, so that calls to it are
			       * intercepted by the given wrapper function. The wrapper function receives,
			       * as its first argument, the original `target` object, followed by each of
			       * the arguments passed to the original method.
			       *
			       * @param {object} target
			       *        The original target object that the wrapped method belongs to.
			       * @param {function} method
			       *        The method being wrapped. This is used as the target of the Proxy
			       *        object which is created to wrap the method.
			       * @param {function} wrapper
			       *        The wrapper function which is called in place of a direct invocation
			       *        of the wrapped method.
			       *
			       * @returns {Proxy<function>}
			       *        A Proxy object for the given method, which invokes the given wrapper
			       *        method in its place.
			       */
			      const wrapMethod = (target, method, wrapper) => {
			        return new Proxy(method, {
			          apply(targetMethod, thisObj, args) {
			            return wrapper.call(thisObj, target, ...args);
			          }
			        });
			      };
			      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);

			      /**
			       * Wraps an object in a Proxy which intercepts and wraps certain methods
			       * based on the given `wrappers` and `metadata` objects.
			       *
			       * @param {object} target
			       *        The target object to wrap.
			       *
			       * @param {object} [wrappers = {}]
			       *        An object tree containing wrapper functions for special cases. Any
			       *        function present in this object tree is called in place of the
			       *        method in the same location in the `target` object tree. These
			       *        wrapper methods are invoked as described in {@see wrapMethod}.
			       *
			       * @param {object} [metadata = {}]
			       *        An object tree containing metadata used to automatically generate
			       *        Promise-based wrapper functions for asynchronous. Any function in
			       *        the `target` object tree which has a corresponding metadata object
			       *        in the same location in the `metadata` tree is replaced with an
			       *        automatically-generated wrapper function, as described in
			       *        {@see wrapAsyncFunction}
			       *
			       * @returns {Proxy<object>}
			       */
			      const wrapObject = (target, wrappers = {}, metadata = {}) => {
			        let cache = Object.create(null);
			        let handlers = {
			          has(proxyTarget, prop) {
			            return prop in target || prop in cache;
			          },
			          get(proxyTarget, prop, receiver) {
			            if (prop in cache) {
			              return cache[prop];
			            }
			            if (!(prop in target)) {
			              return undefined;
			            }
			            let value = target[prop];
			            if (typeof value === "function") {
			              // This is a method on the underlying object. Check if we need to do
			              // any wrapping.

			              if (typeof wrappers[prop] === "function") {
			                // We have a special-case wrapper for this method.
			                value = wrapMethod(target, target[prop], wrappers[prop]);
			              } else if (hasOwnProperty(metadata, prop)) {
			                // This is an async method that we have metadata for. Create a
			                // Promise wrapper for it.
			                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
			                value = wrapMethod(target, target[prop], wrapper);
			              } else {
			                // This is a method that we don't know or care about. Return the
			                // original method, bound to the underlying object.
			                value = value.bind(target);
			              }
			            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
			              // This is an object that we need to do some wrapping for the children
			              // of. Create a sub-object wrapper for it with the appropriate child
			              // metadata.
			              value = wrapObject(value, wrappers[prop], metadata[prop]);
			            } else if (hasOwnProperty(metadata, "*")) {
			              // Wrap all properties in * namespace.
			              value = wrapObject(value, wrappers[prop], metadata["*"]);
			            } else {
			              // We don't need to do any wrapping for this property,
			              // so just forward all access to the underlying object.
			              Object.defineProperty(cache, prop, {
			                configurable: true,
			                enumerable: true,
			                get() {
			                  return target[prop];
			                },
			                set(value) {
			                  target[prop] = value;
			                }
			              });
			              return value;
			            }
			            cache[prop] = value;
			            return value;
			          },
			          set(proxyTarget, prop, value, receiver) {
			            if (prop in cache) {
			              cache[prop] = value;
			            } else {
			              target[prop] = value;
			            }
			            return true;
			          },
			          defineProperty(proxyTarget, prop, desc) {
			            return Reflect.defineProperty(cache, prop, desc);
			          },
			          deleteProperty(proxyTarget, prop) {
			            return Reflect.deleteProperty(cache, prop);
			          }
			        };

			        // Per contract of the Proxy API, the "get" proxy handler must return the
			        // original value of the target if that value is declared read-only and
			        // non-configurable. For this reason, we create an object with the
			        // prototype set to `target` instead of using `target` directly.
			        // Otherwise we cannot return a custom object for APIs that
			        // are declared read-only and non-configurable, such as `chrome.devtools`.
			        //
			        // The proxy handlers themselves will still use the original `target`
			        // instead of the `proxyTarget`, so that the methods and properties are
			        // dereferenced via the original targets.
			        let proxyTarget = Object.create(target);
			        return new Proxy(proxyTarget, handlers);
			      };

			      /**
			       * Creates a set of wrapper functions for an event object, which handles
			       * wrapping of listener functions that those messages are passed.
			       *
			       * A single wrapper is created for each listener function, and stored in a
			       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
			       * retrieve the original wrapper, so that  attempts to remove a
			       * previously-added listener work as expected.
			       *
			       * @param {DefaultWeakMap<function, function>} wrapperMap
			       *        A DefaultWeakMap object which will create the appropriate wrapper
			       *        for a given listener function when one does not exist, and retrieve
			       *        an existing one when it does.
			       *
			       * @returns {object}
			       */
			      const wrapEvent = wrapperMap => ({
			        addListener(target, listener, ...args) {
			          target.addListener(wrapperMap.get(listener), ...args);
			        },
			        hasListener(target, listener) {
			          return target.hasListener(wrapperMap.get(listener));
			        },
			        removeListener(target, listener) {
			          target.removeListener(wrapperMap.get(listener));
			        }
			      });
			      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
			        if (typeof listener !== "function") {
			          return listener;
			        }

			        /**
			         * Wraps an onRequestFinished listener function so that it will return a
			         * `getContent()` property which returns a `Promise` rather than using a
			         * callback API.
			         *
			         * @param {object} req
			         *        The HAR entry object representing the network request.
			         */
			        return function onRequestFinished(req) {
			          const wrappedReq = wrapObject(req, {} /* wrappers */, {
			            getContent: {
			              minArgs: 0,
			              maxArgs: 0
			            }
			          });
			          listener(wrappedReq);
			        };
			      });
			      const onMessageWrappers = new DefaultWeakMap(listener => {
			        if (typeof listener !== "function") {
			          return listener;
			        }

			        /**
			         * Wraps a message listener function so that it may send responses based on
			         * its return value, rather than by returning a sentinel value and calling a
			         * callback. If the listener function returns a Promise, the response is
			         * sent when the promise either resolves or rejects.
			         *
			         * @param {*} message
			         *        The message sent by the other end of the channel.
			         * @param {object} sender
			         *        Details about the sender of the message.
			         * @param {function(*)} sendResponse
			         *        A callback which, when called with an arbitrary argument, sends
			         *        that value as a response.
			         * @returns {boolean}
			         *        True if the wrapped listener returned a Promise, which will later
			         *        yield a response. False otherwise.
			         */
			        return function onMessage(message, sender, sendResponse) {
			          let didCallSendResponse = false;
			          let wrappedSendResponse;
			          let sendResponsePromise = new Promise(resolve => {
			            wrappedSendResponse = function (response) {
			              didCallSendResponse = true;
			              resolve(response);
			            };
			          });
			          let result;
			          try {
			            result = listener(message, sender, wrappedSendResponse);
			          } catch (err) {
			            result = Promise.reject(err);
			          }
			          const isResultThenable = result !== true && isThenable(result);

			          // If the listener didn't returned true or a Promise, or called
			          // wrappedSendResponse synchronously, we can exit earlier
			          // because there will be no response sent from this listener.
			          if (result !== true && !isResultThenable && !didCallSendResponse) {
			            return false;
			          }

			          // A small helper to send the message if the promise resolves
			          // and an error if the promise rejects (a wrapped sendMessage has
			          // to translate the message into a resolved promise or a rejected
			          // promise).
			          const sendPromisedResult = promise => {
			            promise.then(msg => {
			              // send the message value.
			              sendResponse(msg);
			            }, error => {
			              // Send a JSON representation of the error if the rejected value
			              // is an instance of error, or the object itself otherwise.
			              let message;
			              if (error && (error instanceof Error || typeof error.message === "string")) {
			                message = error.message;
			              } else {
			                message = "An unexpected error occurred";
			              }
			              sendResponse({
			                __mozWebExtensionPolyfillReject__: true,
			                message
			              });
			            }).catch(err => {
			              // Print an error on the console if unable to send the response.
			              console.error("Failed to send onMessage rejected reply", err);
			            });
			          };

			          // If the listener returned a Promise, send the resolved value as a
			          // result, otherwise wait the promise related to the wrappedSendResponse
			          // callback to resolve and send it as a response.
			          if (isResultThenable) {
			            sendPromisedResult(result);
			          } else {
			            sendPromisedResult(sendResponsePromise);
			          }

			          // Let Chrome know that the listener is replying.
			          return true;
			        };
			      });
			      const wrappedSendMessageCallback = ({
			        reject,
			        resolve
			      }, reply) => {
			        if (extensionAPIs.runtime.lastError) {
			          // Detect when none of the listeners replied to the sendMessage call and resolve
			          // the promise to undefined as in Firefox.
			          // See https://github.com/mozilla/webextension-polyfill/issues/130
			          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
			            resolve();
			          } else {
			            reject(new Error(extensionAPIs.runtime.lastError.message));
			          }
			        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
			          // Convert back the JSON representation of the error into
			          // an Error instance.
			          reject(new Error(reply.message));
			        } else {
			          resolve(reply);
			        }
			      };
			      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
			        if (args.length < metadata.minArgs) {
			          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
			        }
			        if (args.length > metadata.maxArgs) {
			          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
			        }
			        return new Promise((resolve, reject) => {
			          const wrappedCb = wrappedSendMessageCallback.bind(null, {
			            resolve,
			            reject
			          });
			          args.push(wrappedCb);
			          apiNamespaceObj.sendMessage(...args);
			        });
			      };
			      const staticWrappers = {
			        devtools: {
			          network: {
			            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
			          }
			        },
			        runtime: {
			          onMessage: wrapEvent(onMessageWrappers),
			          onMessageExternal: wrapEvent(onMessageWrappers),
			          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
			            minArgs: 1,
			            maxArgs: 3
			          })
			        },
			        tabs: {
			          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
			            minArgs: 2,
			            maxArgs: 3
			          })
			        }
			      };
			      const settingMetadata = {
			        clear: {
			          minArgs: 1,
			          maxArgs: 1
			        },
			        get: {
			          minArgs: 1,
			          maxArgs: 1
			        },
			        set: {
			          minArgs: 1,
			          maxArgs: 1
			        }
			      };
			      apiMetadata.privacy = {
			        network: {
			          "*": settingMetadata
			        },
			        services: {
			          "*": settingMetadata
			        },
			        websites: {
			          "*": settingMetadata
			        }
			      };
			      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
			    };

			    // The build process adds a UMD wrapper around this file, which makes the
			    // `module` variable available.
			    module.exports = wrapAPIs(chrome);
			  } else {
			    module.exports = globalThis.browser;
			  }
			});
			
		} (browserPolyfill$1));
		return browserPolyfill$1.exports;
	}

	var browserPolyfillExports = requireBrowserPolyfill();
	var browser = /*@__PURE__*/getDefaultExportFromCjs(browserPolyfillExports);

	const IGNORED_EXACT_ENDPOINTS = new Set(['/', '/*', '//', '/$', '/**/', '/#', 'MM/dd/yyyy', 'yyyy/MM/dd', 'Gyy/MM/dd', 'dd.MM.yyyy', 'yyyy.MM.dd', 'Gyy.MM.dd', 'multipart/mixed', 'https://js.foundation/', 'http://www.json.org/', 'n/a', '/..', '//google-analytics.com', '//googletagmanager.com']);
	const IGNORED_ENDPOINT_PREFIXES = ['audio/', 'image/', 'jquery.', 'text/', 'video/', 'application/', 'http://www.w3.org/', 'http://jqueryui.com/', 'https://jquery.com/', 'https://jquery.org/', 'javascript:', 'https://www.googletagmanager.com', 'https://www.gstatic.com/', 'Asia/', 'America/', 'Europe/', 'Africa/', 'Australia/', 'Antarctica/', 'Pacific/', 'Atlantic/', 'Arctic/', 'Etc/'];
	const IGNORED_ENDPOINT_SUFFIXES = ['.css', 'set_cookie?', '.woff2', '.svg'];
	const IGNORED_SOURCE_PREFIXES = ['https://www.googletagmanager.com'];
	const IGNORED_WEBPAGE_SUBSTRINGS = ['bugcrowd.com'];
	function normalizeEndpointForDedupe(endpoint) {
	    return endpoint.trim();
	}
	function shouldCaptureEndpoint(endpoint) {
	    const normalizedEndpoint = normalizeEndpointForDedupe(endpoint);
	    return (!IGNORED_EXACT_ENDPOINTS.has(normalizedEndpoint) &&
	        !IGNORED_ENDPOINT_PREFIXES.some(prefix => normalizedEndpoint.startsWith(prefix)) &&
	        !IGNORED_ENDPOINT_SUFFIXES.some(suffix => normalizedEndpoint.endsWith(suffix)));
	}
	function shouldCaptureSource(source) {
	    return !IGNORED_SOURCE_PREFIXES.some(prefix => source.startsWith(prefix));
	}
	function shouldCaptureWebpage(webpage) {
	    const normalizedWebpage = webpage.toLowerCase();
	    return !IGNORED_WEBPAGE_SUBSTRINGS.some(substring => normalizedWebpage.includes(substring));
	}
	function filterCapturedEndpoints(endpoints) {
	    return Array.from(endpoints).filter(shouldCaptureEndpoint);
	}

	function normalizeScope(value) {
	    const trimmedValue = value.trim().toLowerCase();
	    if (!trimmedValue) {
	        return '';
	    }
	    const withoutWildcard = trimmedValue.replace(/^\*\./, '');
	    try {
	        const candidate = withoutWildcard.includes('://')
	            ? withoutWildcard
	            : `https://${withoutWildcard}`;
	        return new URL(candidate).hostname.replace(/^\.+|\.+$/g, '');
	    }
	    catch {
	        return withoutWildcard
	            .split('/')[0]
	            .replace(/:\d+$/, '')
	            .replace(/^\.+|\.+$/g, '');
	    }
	}
	function matchesHostBoundary(host, scopes) {
	    const normalizedHost = normalizeScope(host);
	    return scopes.some((scope) => {
	        const normalizedScope = normalizeScope(scope);
	        return Boolean(normalizedScope) &&
	            (normalizedHost === normalizedScope || normalizedHost.endsWith(`.${normalizedScope}`));
	    });
	}
	function isHostInScopes(host, scopes) {
	    return scopes.length === 0 || matchesHostBoundary(host, scopes);
	}
	function isHostAllowed(host, scopes, outOfScopes) {
	    return !matchesHostBoundary(host, outOfScopes) && isHostInScopes(host, scopes);
	}

	function safeDecodeURIComponent$1(value) {
	    try {
	        return decodeURIComponent(value);
	    }
	    catch {
	        return value;
	    }
	}
	class StorageService {
	    static async getConcurrencySetting() {
	        const result = await browser.storage.local.get('requests');
	        return result.requests || 1;
	    }
	    static async isInScope(host) {
	        const result = await browser.storage.local.get(['scope', 'outOfScope']);
	        const scopes = result.scope || [];
	        const outOfScopes = result.outOfScope || [];
	        return isHostAllowed(host, scopes, outOfScopes);
	    }
	    static async isURLExcluded(url) {
	        try {
	            const result = await browser.storage.local.get('outOfScope');
	            const outOfScopes = result.outOfScope || [];
	            return matchesHostBoundary(new URL(url).hostname, outOfScopes);
	        }
	        catch {
	            return false;
	        }
	    }
	    static async saveToStorage(encodedURL, urls) {
	        const result = await browser.storage.local.get('URL-PARSER');
	        const urlParser = result['URL-PARSER'] || {};
	        const currentURL = urlParser.current || '';
	        const decodedURL = decodeURIComponent(encodedURL);
	        if (!shouldCaptureWebpage(safeDecodeURIComponent$1(currentURL))) {
	            return;
	        }
	        if (!shouldCaptureSource(decodedURL)) {
	            return;
	        }
	        if (!urlParser[currentURL]) {
	            urlParser[currentURL] = {
	                currPage: [],
	                externalJSFiles: {}
	            };
	        }
	        if (!urlParser[currentURL].externalJSFiles) {
	            urlParser[currentURL].externalJSFiles = {};
	        }
	        urlParser[currentURL].externalJSFiles[encodedURL] = urls
	            .map(safeDecodeURIComponent$1)
	            .filter(shouldCaptureEndpoint)
	            .map(url => ({
	            url,
	            classifications: {}
	        }));
	        await browser.storage.local.set({ 'URL-PARSER': urlParser });
	    }
	    static async savePageSecrets(encodedPageURL, secrets) {
	        const result = await browser.storage.local.get('SECRET-PARSER');
	        const secretParser = result['SECRET-PARSER'] || {};
	        if (!secretParser[encodedPageURL] || typeof secretParser[encodedPageURL] === 'string') {
	            secretParser[encodedPageURL] = {
	                currPage: [],
	                externalJSFiles: {}
	            };
	        }
	        const currentPageData = secretParser[encodedPageURL];
	        currentPageData.currPage = this.mergeSecrets(currentPageData.currPage, secrets);
	        secretParser.current = encodedPageURL;
	        await browser.storage.local.set({ 'SECRET-PARSER': secretParser });
	        await this.updateSecretCount(await this.countAllSecrets(secretParser));
	    }
	    static async saveJSFileSecrets(encodedURL, secrets) {
	        const result = await browser.storage.local.get('SECRET-PARSER');
	        const secretParser = result['SECRET-PARSER'] || {};
	        const currentURL = secretParser.current || '';
	        if (!currentURL) {
	            return;
	        }
	        if (!secretParser[currentURL] || typeof secretParser[currentURL] === 'string') {
	            secretParser[currentURL] = {
	                currPage: [],
	                externalJSFiles: {}
	            };
	        }
	        const currentPageData = secretParser[currentURL];
	        const existingSecrets = currentPageData.externalJSFiles[encodedURL] || [];
	        currentPageData.externalJSFiles[encodedURL] = this.mergeSecrets(existingSecrets, secrets);
	        await browser.storage.local.set({ 'SECRET-PARSER': secretParser });
	        await this.updateSecretCount(await this.countCurrentSecrets(secretParser));
	    }
	    static async saveJSFileSecretsForPage(encodedPageURL, encodedURL, secrets) {
	        const result = await browser.storage.local.get('SECRET-PARSER');
	        const secretParser = result['SECRET-PARSER'] || {};
	        if (!secretParser[encodedPageURL] || typeof secretParser[encodedPageURL] === 'string') {
	            secretParser[encodedPageURL] = {
	                currPage: [],
	                externalJSFiles: {}
	            };
	        }
	        const currentPageData = secretParser[encodedPageURL];
	        const existingSecrets = currentPageData.externalJSFiles[encodedURL] || [];
	        currentPageData.externalJSFiles[encodedURL] = this.mergeSecrets(existingSecrets, secrets);
	        secretParser.current = encodedPageURL;
	        await browser.storage.local.set({ 'SECRET-PARSER': secretParser });
	        await this.updateSecretCount(await this.countAllSecrets(secretParser));
	    }
	    static async updateURLCount(count) {
	        await browser.storage.local.set({ urlCount: count });
	    }
	    static async updateJSFileCount(count) {
	        await browser.storage.local.set({ jsFileCount: count });
	    }
	    static async updateSecretCount(count) {
	        await browser.storage.local.set({ secretCount: count });
	    }
	    static mergeSecrets(existingSecrets, newSecrets) {
	        const bySecret = new Map();
	        existingSecrets.forEach((secret) => {
	            bySecret.set(this.getSecretDedupeKey(secret), secret);
	        });
	        newSecrets.forEach((secret) => {
	            const key = this.getSecretDedupeKey(secret);
	            if (!bySecret.has(key)) {
	                bySecret.set(key, secret);
	            }
	        });
	        return Array.from(bySecret.values());
	    }
	    static getSecretDedupeKey(secret) {
	        return `${secret.detectorId}:${secret.secret}`;
	    }
	    static async countCurrentSecrets(secretParser) {
	        const currentURL = secretParser.current;
	        if (!currentURL) {
	            return 0;
	        }
	        const currentPageData = secretParser[currentURL];
	        if (!currentPageData || typeof currentPageData === 'string') {
	            return 0;
	        }
	        return currentPageData.currPage.length +
	            Object.values(currentPageData.externalJSFiles).reduce((total, secrets) => total + secrets.length, 0);
	    }
	    static async countAllSecrets(secretParser) {
	        return Object.entries(secretParser).reduce((total, [key, value]) => {
	            if (key === 'current' || typeof value === 'string' || value === undefined) {
	                return total;
	            }
	            return total + value.currPage.length +
	                Object.values(value.externalJSFiles).reduce((sum, secrets) => sum + secrets.length, 0);
	        }, 0);
	    }
	}

	// Capture quoted relative paths and asset-like strings, including token placeholders such as `%s`.
	const REL_REGEX = /["']((\/|(\w+\/))[^"'`\s<>{}()]*)["']/g;
	const ABS_REGEX = /(https?:\/\/[^\s'"){}(]+)/g;
	// Capture quoted bare domains/hostnames such as `.chemistwarehouse.com.au`, `translate.googleusercontent.com`, and `localhost`.
	const DOMAIN_REGEX = /["']((?:\.[a-z0-9-]+(?:\.[a-z0-9-]+)+)|(?:[a-z0-9-]+(?:\.[a-z0-9-]+){2,})|(?:localhost))(?:["'])/gi;

	class PageParser {
	    async parseCurrentPage() {
	        if (!shouldCaptureWebpage(document.location.href)) {
	            return new Set();
	        }
	        const pageContent = document.documentElement?.outerHTML || document.body?.outerHTML || '';
	        const abPageURLs = Array.from(pageContent.matchAll(ABS_REGEX), match => match[1]);
	        const relPageURLs = Array.from(pageContent.matchAll(REL_REGEX), match => match[1]);
	        const pageDomains = Array.from(pageContent.matchAll(DOMAIN_REGEX), match => match[1]);
	        const pageURLs = new Set(filterCapturedEndpoints([...abPageURLs, ...relPageURLs, ...pageDomains]));
	        const currPage = encodeURIComponent(document.location.href);
	        const mergedURLCount = await this.saveToBrowser(currPage, pageURLs);
	        await StorageService.updateURLCount(mergedURLCount);
	        return pageURLs;
	    }
	    async saveToBrowser(currPage, pageURLs) {
	        const result = await browser.storage.local.get('URL-PARSER');
	        const urlParser = result['URL-PARSER'] || {};
	        if (!urlParser[currPage]) {
	            urlParser[currPage] = {
	                currPage: Array.from(pageURLs).map(url => ({
	                    url,
	                    classifications: {}
	                })),
	                externalJSFiles: {}
	            };
	        }
	        const existingPageData = urlParser[currPage];
	        const existingURLs = Array.isArray(existingPageData?.currPage) ? existingPageData.currPage : [];
	        const urlsByValue = new Map(existingURLs.map((entry) => [entry.url, entry]));
	        Array.from(pageURLs).forEach((url) => {
	            if (!urlsByValue.has(url)) {
	                urlsByValue.set(url, {
	                    url,
	                    classifications: {}
	                });
	            }
	        });
	        urlParser[currPage].currPage = Array.from(urlsByValue.values());
	        urlParser.current = currPage;
	        await browser.storage.local.set({ 'URL-PARSER': urlParser });
	        return urlParser[currPage].currPage.length;
	    }
	    getScriptFiles() {
	        const scriptTags = document.getElementsByTagName('script');
	        return Array.from(scriptTags).filter(script => script.src).map(script => script.src);
	    }
	    setupScriptObserver(onNewScripts) {
	        const observer = new MutationObserver((mutations) => {
	            for (let mutation of mutations) {
	                if (mutation.type === 'childList') {
	                    const addedScripts = Array.from(mutation.addedNodes)
	                        .filter((node) => node.nodeName === 'SCRIPT' &&
	                        node instanceof HTMLScriptElement &&
	                        node.src !== '')
	                        .map(script => script.src);
	                    if (addedScripts.length > 0) {
	                        onNewScripts(addedScripts);
	                    }
	                }
	            }
	        });
	        if (document.documentElement) {
	            observer.observe(document.documentElement, {
	                childList: true,
	                subtree: true
	            });
	        }
	        return observer;
	    }
	}

	const PARSER_CONFIG = {
	    MAX_RETRY_ATTEMPTS: 3,
	    FETCH_TIMEOUT: 3000,
	    MAX_FILES_TO_PROCESS: 300,
	    MAX_PROCESSING_TIME: 1000,
	    DEFAULT_CONCURRENT_REQUESTS: 1
	};

	class JSFileProcessor {
	    parsedJSFiles = new Set();
	    successfullyFetchedFiles = new Set();
	    failedFetchAttempts = new Map();
	    concurrentRequests = 1;
	    progressBar;
	    constructor(progressBar) {
	        this.progressBar = progressBar;
	    }
	    async processBatch(js_files) {
	        const processingStart = Date.now();
	        let lastLogTime = processingStart;
	        const totalFiles = Math.min(js_files.length, PARSER_CONFIG.MAX_FILES_TO_PROCESS);
	        let processedFiles = 0;
	        while (this.parsedJSFiles.size < js_files.length &&
	            this.parsedJSFiles.size < PARSER_CONFIG.MAX_FILES_TO_PROCESS &&
	            (Date.now() - processingStart) < PARSER_CONFIG.MAX_PROCESSING_TIME) {
	            const unparsedFiles = js_files
	                .filter(file => !this.parsedJSFiles.has(file) &&
	                (!this.failedFetchAttempts.has(file) ||
	                    this.failedFetchAttempts.get(file) < PARSER_CONFIG.MAX_RETRY_ATTEMPTS))
	                .slice(0, PARSER_CONFIG.MAX_FILES_TO_PROCESS - this.parsedJSFiles.size);
	            for (let i = 0; i < unparsedFiles.length; i += this.concurrentRequests) {
	                const batch = unparsedFiles.slice(i, i + this.concurrentRequests);
	                await Promise.all(batch.map(js_file => this.processFile(js_file)));
	                processedFiles += batch.length;
	                const progress = (processedFiles / totalFiles) * 100;
	                if (Date.now() - lastLogTime > 100 || processedFiles >= totalFiles) {
	                    console.log(`Processed ${processedFiles} out of ${totalFiles} JS files. ${this.successfullyFetchedFiles.size} successful, ${this.failedFetchAttempts.size} failed.`);
	                    this.progressBar.update(progress, `Parsing... (${processedFiles}/${totalFiles})`); // Call on instance
	                    lastLogTime = Date.now();
	                }
	            }
	        }
	        await StorageService.updateJSFileCount(this.successfullyFetchedFiles.size);
	    }
	    async processFile(js_file) {
	        if (!this.parsedJSFiles.has(js_file)) {
	            try {
	                if (await StorageService.isURLExcluded(js_file)) {
	                    this.parsedJSFiles.add(js_file);
	                    return;
	                }
	                const code = await this.fetchWithTimeout(js_file);
	                this.successfullyFetchedFiles.add(js_file);
	                const jsFileRelURLs = Array.from(code.matchAll(REL_REGEX), match => match[1]);
	                const jsFileAbURLs = Array.from(code.matchAll(ABS_REGEX), match => match[1]);
	                const jsFileDomains = Array.from(code.matchAll(DOMAIN_REGEX), match => match[1]);
	                const jsFileURLs = new Set([...jsFileRelURLs, ...jsFileAbURLs, ...jsFileDomains]);
	                const encodedURL = encodeURIComponent(js_file);
	                await StorageService.saveToStorage(encodedURL, Array.from(jsFileURLs));
	                this.parsedJSFiles.add(js_file);
	            }
	            catch (error) {
	                const attempts = (this.failedFetchAttempts.get(js_file) || 0) + 1;
	                this.failedFetchAttempts.set(js_file, attempts);
	            }
	        }
	    }
	    async fetchWithTimeout(file) {
	        const controller = new AbortController();
	        const id = setTimeout(() => controller.abort(), PARSER_CONFIG.FETCH_TIMEOUT);
	        try {
	            const response = await fetch(file, { signal: controller.signal });
	            clearTimeout(id);
	            const text = await response.text();
	            return text;
	        }
	        catch (error) {
	            clearTimeout(id);
	            throw error;
	        }
	    }
	    async setConcurrentRequests() {
	        this.concurrentRequests = await StorageService.getConcurrencySetting();
	    }
	    getStats() {
	        return {
	            processed: this.parsedJSFiles.size,
	            successful: this.successfullyFetchedFiles.size,
	            failed: this.failedFetchAttempts.size
	        };
	    }
	}

	class ProgressBar {
	    element = null;
	    create() {
	        const container = document.createElement('div');
	        container.id = 'parsing-progress-container';
	        container.setAttribute('aria-live', 'polite');
	        container.style.cssText = `
      position: fixed;
      top: 16px;
      right: 16px;
      width: 232px;
      z-index: 2147483647;
      pointer-events: none;
    `;
	        const shadow = container.attachShadow({ mode: 'closed' });
	        shadow.innerHTML = `
      <style>
        :host {
          all: initial;
        }

        .card {
          box-sizing: border-box;
          width: 100%;
          overflow: hidden;
          border: 1px solid rgba(123, 211, 226, 0.26);
          border-radius: 12px;
          background: rgba(12, 27, 34, 0.94);
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.24);
          color: #effcff;
          font-family: Inter, "Segoe UI", Arial, sans-serif;
          backdrop-filter: blur(12px);
          animation: enter 160ms ease-out;
        }

        .content {
          display: grid;
          grid-template-columns: 30px minmax(0, 1fr) auto;
          align-items: center;
          gap: 9px;
          padding: 10px 11px 9px;
        }

        .icon {
          display: grid;
          width: 28px;
          height: 28px;
          place-items: center;
          border: 1px solid rgba(85, 226, 211, 0.28);
          border-radius: 9px;
          background: linear-gradient(145deg, rgba(38, 166, 174, 0.26), rgba(31, 90, 116, 0.2));
        }

        .spinner {
          box-sizing: border-box;
          width: 14px;
          height: 14px;
          border: 2px solid rgba(154, 239, 239, 0.24);
          border-top-color: #65e4d5;
          border-radius: 50%;
          animation: spin 800ms linear infinite;
        }

        .copy {
          min-width: 0;
        }

        .title {
          overflow: hidden;
          color: #ecfdff;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.03em;
          line-height: 1.2;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .status {
          overflow: hidden;
          margin-top: 2px;
          color: #9fc4cd;
          font-size: 9px;
          line-height: 1.2;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .percent {
          color: #92eee1;
          font-size: 10px;
          font-variant-numeric: tabular-nums;
          font-weight: 700;
        }

        .track {
          height: 2px;
          background: rgba(137, 200, 211, 0.14);
        }

        .fill {
          width: 0%;
          height: 100%;
          border-radius: 0 2px 2px 0;
          background: linear-gradient(90deg, #32c5bf, #83edcf);
          box-shadow: 0 0 8px rgba(76, 221, 206, 0.5);
          transition: width 220ms ease;
        }

        .card.done .spinner {
          border: 0;
          animation: none;
        }

        .card.done .spinner::after {
          color: #73e3b2;
          content: "✓";
          font-size: 14px;
          font-weight: 800;
        }

        .card.error {
          border-color: rgba(255, 121, 137, 0.4);
        }

        .card.error .spinner {
          border: 0;
          animation: none;
        }

        .card.error .spinner::after {
          color: #ff8996;
          content: "!";
          font-size: 14px;
          font-weight: 800;
        }

        .card.error .fill {
          background: #ff7e90;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        @keyframes enter {
          from { opacity: 0; transform: translateY(-5px) scale(0.98); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @media (max-width: 480px) {
          .card {
            width: 200px;
          }
        }
      </style>
      <div class="card">
        <div class="content">
          <div class="icon"><div class="spinner"></div></div>
          <div class="copy">
            <div class="title">DeepTrace scanning</div>
            <div class="status">Checking page endpoints</div>
          </div>
          <div class="percent">0%</div>
        </div>
        <div class="track"><div class="fill"></div></div>
      </div>
    `;
	        const card = shadow.querySelector('.card');
	        const progressFill = shadow.querySelector('.fill');
	        const percentText = shadow.querySelector('.percent');
	        const statusText = shadow.querySelector('.status');
	        container.setProgress = (progress) => {
	            const normalizedProgress = Math.min(100, Math.max(0, Math.round(progress)));
	            progressFill.style.width = `${normalizedProgress}%`;
	            percentText.textContent = `${normalizedProgress}%`;
	            card.classList.toggle('done', normalizedProgress === 100 && !card.classList.contains('error'));
	        };
	        container.setStatus = (status) => {
	            const hasError = status.toLowerCase().includes('error');
	            card.classList.toggle('error', hasError);
	            statusText.textContent = status.replace(/\.\.\./g, '').trim() || 'Checking page endpoints';
	        };
	        document.documentElement.appendChild(container);
	        return container;
	    }
	    update(progress, status) {
	        if (!this.element || !this.element.isConnected) {
	            this.element = this.create();
	        }
	        this.element.setStatus(status);
	        this.element.setProgress(progress);
	    }
	    remove() {
	        this.element?.remove();
	        this.element = null;
	    }
	}

	const MAX_SECRET_LENGTH = 240;
	const MIN_CONFIG_SECRET_LENGTH = 4;
	const CONTEXT_RADIUS = 80;
	const SCAN_YIELD_INTERVAL = 25;
	function hasReasonableEntropy(value) {
	    const normalized = value.trim();
	    if (normalized.length < 16) {
	        return false;
	    }
	    const counts = new Map();
	    for (const char of normalized) {
	        counts.set(char, (counts.get(char) || 0) + 1);
	    }
	    let entropy = 0;
	    counts.forEach((count) => {
	        const probability = count / normalized.length;
	        entropy -= probability * Math.log2(probability);
	    });
	    return entropy >= 3.25;
	}
	function looksLikePlaceholder(value) {
	    const lowered = value.toLowerCase();
	    return [
	        'example',
	        'sample',
	        'placeholder',
	        'changeme',
	        'your_',
	        'your-',
	        'dummy',
	        'testtest',
	        'xxxxxxxx',
	        'aaaaaaaa',
	        '00000000',
	        '12345678',
	    ].some((marker) => lowered.includes(marker));
	}
	function isLikelyToken(value) {
	    const secret = value.trim();
	    return secret.length <= MAX_SECRET_LENGTH && !looksLikePlaceholder(secret) && hasReasonableEntropy(secret);
	}
	function looksLikeNonSecretConfigValue(value) {
	    const normalized = value.trim().toLowerCase();
	    if (!normalized) {
	        return true;
	    }
	    return [
	        'true',
	        'false',
	        'enabled',
	        'disabled',
	        'enable',
	        'disable',
	        'yes',
	        'no',
	        'null',
	        'undefined',
	        'production',
	        'development',
	        'staging',
	        'test',
	    ].includes(normalized);
	}
	function isPotentialConfigSecret(value) {
	    const secret = value.trim();
	    return (secret.length >= MIN_CONFIG_SECRET_LENGTH &&
	        secret.length <= MAX_SECRET_LENGTH &&
	        !looksLikePlaceholder(secret) &&
	        !looksLikeNonSecretConfigValue(secret) &&
	        !/^https?:\/\//i.test(secret));
	}
	function buildAssignmentPattern(names) {
	    return new RegExp(String.raw `\b(?:${names})\b\s*(?:=|:|=>)\s*["'\`]?(?<secret>[A-Za-z0-9_./+=:@%$-]{16,${MAX_SECRET_LENGTH}})["'\`]?`, 'gi');
	}
	function buildConfigAssignmentPattern(names) {
	    return new RegExp(String.raw `\b(?:${names})\b\s*(?:=|:|=>)\s*["'\`]?(?<secret>[^"'\x60,\r\n]{${MIN_CONFIG_SECRET_LENGTH},${MAX_SECRET_LENGTH}})["'\`]?`, 'gi');
	}
	function assignmentDetector(id, name, names, severity = 'high', confidence = 78) {
	    return {
	        id,
	        name,
	        pattern: buildAssignmentPattern(names),
	        severity,
	        confidence,
	        validate: (secret) => isLikelyToken(secret) && !/^https?:\/\//i.test(secret),
	    };
	}
	const API_KEY_WORDS = String.raw `api(?:_|-)?key|access(?:_|-)?key|secret(?:_|-)?key`;
	const API_TOKEN_WORDS = String.raw `api(?:_|-)?token|access(?:_|-)?token|auth(?:_|-)?token|bearer(?:_|-)?token|refresh(?:_|-)?token`;
	const SECRET_WORDS = String.raw `client(?:_|-)?secret|consumer(?:_|-)?secret|app(?:_|-)?secret|signing(?:_|-)?secret|webhook(?:_|-)?secret|private(?:_|-)?key`;
	const PUBLIC_CONFIG_PREFIXES = String.raw `next(?:_|-)?public|vite|react(?:_|-)?app|public`;
	const PUBLIC_CONFIG_SECRET_WORDS = String.raw `api(?:_|-)?key|access(?:_|-)?key|secret(?:_|-)?key|site(?:_|-)?key|store(?:_|-)?key|public(?:_|-)?key|publishable(?:_|-)?key|token|access(?:_|-)?token|auth(?:_|-)?token|bearer(?:_|-)?token|refresh(?:_|-)?token|preview(?:_|-)?token|static(?:_|-)?token|client(?:_|-)?secret|consumer(?:_|-)?secret|app(?:_|-)?secret|user(?:_|-)?agent(?:_|-)?secret|validation(?:_|-)?secret|webhook(?:_|-)?secret|private(?:_|-)?key|client(?:_|-)?id|app(?:_|-)?id|application(?:_|-)?id|space(?:_|-)?id|list(?:_|-)?id|company(?:_|-)?id|account(?:_|-)?id|tenant(?:_|-)?id|subscription(?:_|-)?form(?:_|-)?(?:mobile|desktop|id)?|sms(?:_|-)?list(?:_|-)?id`;
	const PROVIDER_ASSIGNMENT_DETECTORS = [
	    assignmentDetector('openai-assignment', 'OpenAI Secret', String.raw `openai(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 88),
	    assignmentDetector('anthropic-assignment', 'Anthropic Secret', String.raw `anthropic(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 88),
	    assignmentDetector('azure-assignment', 'Azure Secret', String.raw `azure(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|storage(?:_|-)?key|tenant(?:_|-)?secret)`, 'critical', 86),
	    assignmentDetector('gcp-assignment', 'Google Cloud Secret', String.raw `(?:gcp|google(?:_|-)?cloud)(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 86),
	    assignmentDetector('cloudflare-assignment', 'Cloudflare Secret', String.raw `cloudflare(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 86),
	    assignmentDetector('digitalocean-assignment', 'DigitalOcean Secret', String.raw `(?:digitalocean|do)(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('linode-assignment', 'Linode Secret', String.raw `linode(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('heroku-assignment', 'Heroku Secret', String.raw `heroku(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('vercel-assignment', 'Vercel Secret', String.raw `vercel(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('netlify-assignment', 'Netlify Secret', String.raw `netlify(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('flyio-assignment', 'Fly.io Secret', String.raw `fly(?:_|-)?io(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'high', 82),
	    assignmentDetector('render-assignment', 'Render Secret', String.raw `render(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'high', 82),
	    assignmentDetector('railway-assignment', 'Railway Secret', String.raw `railway(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'high', 82),
	    assignmentDetector('supabase-assignment', 'Supabase Secret', String.raw `supabase(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|service(?:_|-)?role)`, 'critical', 84),
	    assignmentDetector('firebase-assignment', 'Firebase Secret', String.raw `firebase(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|private(?:_|-)?key)`, 'high', 80),
	    assignmentDetector('clerk-assignment', 'Clerk Secret', String.raw `clerk(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('auth0-assignment', 'Auth0 Secret', String.raw `auth0(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|client(?:_|-)?id)`, 'critical', 84),
	    assignmentDetector('okta-assignment', 'Okta Secret', String.raw `okta(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('cognito-assignment', 'AWS Cognito Secret', String.raw `cognito(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'high', 80),
	    assignmentDetector('github-assignment', 'GitHub Secret', String.raw `github(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|pat|oauth(?:_|-)?token)`, 'critical', 86),
	    assignmentDetector('gitlab-assignment', 'GitLab Secret', String.raw `gitlab(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|pat)`, 'critical', 86),
	    assignmentDetector('bitbucket-assignment', 'Bitbucket Secret', String.raw `bitbucket(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|app(?:_|-)?password)`, 'critical', 84),
	    assignmentDetector('atlassian-assignment', 'Atlassian Secret', String.raw `(?:atlassian|jira|confluence)(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('slack-assignment', 'Slack Secret', String.raw `slack(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|bot(?:_|-)?token|webhook)`, 'critical', 86),
	    assignmentDetector('discord-assignment', 'Discord Secret', String.raw `discord(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|bot(?:_|-)?token|webhook)`, 'critical', 84),
	    assignmentDetector('telegram-assignment', 'Telegram Secret', String.raw `telegram(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|bot(?:_|-)?token)`, 'critical', 84),
	    assignmentDetector('twilio-assignment', 'Twilio Secret', String.raw `twilio(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|account(?:_|-)?sid|auth(?:_|-)?token)`, 'critical', 86),
	    assignmentDetector('sendgrid-assignment', 'SendGrid Secret', String.raw `sendgrid(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 86),
	    assignmentDetector('mailgun-assignment', 'Mailgun Secret', String.raw `mailgun(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('mailchimp-assignment', 'Mailchimp Secret', String.raw `mailchimp(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('postmark-assignment', 'Postmark Secret', String.raw `postmark(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|server(?:_|-)?token)`, 'high', 82),
	    assignmentDetector('stripe-assignment', 'Stripe Secret', String.raw `stripe(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|restricted(?:_|-)?key)`, 'critical', 88),
	    assignmentDetector('paypal-assignment', 'PayPal Secret', String.raw `paypal(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|client(?:_|-)?id)`, 'critical', 84),
	    assignmentDetector('square-assignment', 'Square Secret', String.raw `square(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('razorpay-assignment', 'Razorpay Secret', String.raw `razorpay(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('plaid-assignment', 'Plaid Secret', String.raw `plaid(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('coinbase-assignment', 'Coinbase Secret', String.raw `coinbase(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('shopify-assignment', 'Shopify Secret', String.raw `shopify(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 86),
	    assignmentDetector('stripe-webhook-assignment', 'Stripe Webhook Secret', String.raw `stripe(?:_|-)?webhook(?:_|-)?secret|webhook(?:_|-)?signing(?:_|-)?secret`, 'critical', 86),
	    assignmentDetector('algolia-assignment', 'Algolia Secret', String.raw `algolia(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|admin(?:_|-)?key|search(?:_|-)?key)`, 'high', 82),
	    assignmentDetector('mapbox-assignment', 'Mapbox Secret', String.raw `mapbox(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'high', 82),
	    assignmentDetector('contentful-assignment', 'Contentful Secret', String.raw `contentful(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'high', 82),
	    assignmentDetector('sanity-assignment', 'Sanity Secret', String.raw `sanity(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'high', 82),
	    assignmentDetector('cloudinary-assignment', 'Cloudinary Secret', String.raw `cloudinary(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|url)`, 'critical', 84),
	    assignmentDetector('datadog-assignment', 'Datadog Secret', String.raw `datadog(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|app(?:_|-)?key)`, 'critical', 84),
	    assignmentDetector('newrelic-assignment', 'New Relic Secret', String.raw `new(?:_|-)?relic(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|license(?:_|-)?key)`, 'critical', 84),
	    assignmentDetector('sentry-assignment', 'Sentry Secret', String.raw `sentry(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|dsn|auth(?:_|-)?token)`, 'high', 80),
	    assignmentDetector('grafana-assignment', 'Grafana Secret', String.raw `grafana(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|service(?:_|-)?account(?:_|-)?token)`, 'critical', 84),
	    assignmentDetector('honeycomb-assignment', 'Honeycomb Secret', String.raw `honeycomb(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'high', 82),
	    assignmentDetector('snyk-assignment', 'Snyk Secret', String.raw `snyk(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('sonarqube-assignment', 'SonarQube Secret', String.raw `(?:sonar|sonarqube)(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('vault-assignment', 'HashiCorp Vault Secret', String.raw `(?:vault|hashicorp)(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|root(?:_|-)?token)`, 'critical', 86),
	    assignmentDetector('terraform-assignment', 'Terraform Cloud Secret', String.raw `terraform(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|cloud(?:_|-)?token)`, 'critical', 84),
	    assignmentDetector('pulumi-assignment', 'Pulumi Secret', String.raw `pulumi(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('docker-assignment', 'Docker Secret', String.raw `docker(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|hub(?:_|-)?token|pat)`, 'critical', 84),
	    assignmentDetector('npm-assignment', 'npm Secret', String.raw `npm(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('pypi-assignment', 'PyPI Secret', String.raw `pypi(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('huggingface-assignment', 'Hugging Face Secret', String.raw `(?:huggingface|hugging(?:_|-)?face|hf)(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('replicate-assignment', 'Replicate Secret', String.raw `replicate(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('pinecone-assignment', 'Pinecone Secret', String.raw `pinecone(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('cohere-assignment', 'Cohere Secret', String.raw `cohere(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('mistral-assignment', 'Mistral Secret', String.raw `mistral(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('groq-assignment', 'Groq Secret', String.raw `groq(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('langsmith-assignment', 'LangSmith Secret', String.raw `langsmith(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('linear-assignment', 'Linear Secret', String.raw `linear(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('notion-assignment', 'Notion Secret', String.raw `notion(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|integration(?:_|-)?token)`, 'critical', 84),
	    assignmentDetector('airtable-assignment', 'Airtable Secret', String.raw `airtable(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|pat)`, 'critical', 84),
	    assignmentDetector('postman-assignment', 'Postman Secret', String.raw `postman(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('zapier-assignment', 'Zapier Secret', String.raw `zapier(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|webhook)`, 'high', 80),
	    assignmentDetector('zapier-webhook-assignment', 'Zapier Webhook Secret', String.raw `hooks(?:_|-)?zapier(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'high', 80),
	    assignmentDetector('segment-assignment', 'Segment Secret', String.raw `segment(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|write(?:_|-)?key)`, 'high', 80),
	    assignmentDetector('launchdarkly-assignment', 'LaunchDarkly Secret', String.raw `launch(?:_|-)?darkly(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|sdk(?:_|-)?key)`, 'high', 80),
	    assignmentDetector('splitio-assignment', 'Split.io Secret', String.raw `split(?:_|-)?io(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|sdk(?:_|-)?key)`, 'high', 80),
	    assignmentDetector('intercom-assignment', 'Intercom Secret', String.raw `intercom(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'high', 80),
	    assignmentDetector('hubspot-assignment', 'HubSpot Secret', String.raw `hubspot(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|private(?:_|-)?app(?:_|-)?token)`, 'critical', 84),
	    assignmentDetector('zendesk-assignment', 'Zendesk Secret', String.raw `zendesk(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('freshdesk-assignment', 'Freshdesk Secret', String.raw `freshdesk(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'high', 80),
	    assignmentDetector('dropbox-assignment', 'Dropbox Secret', String.raw `dropbox(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('box-assignment', 'Box Secret', String.raw `box(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'high', 80),
	    assignmentDetector('microsoft-graph-assignment', 'Microsoft Graph Secret', String.raw `(?:microsoft(?:_|-)?graph|ms(?:_|-)?graph)(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('zoom-assignment', 'Zoom Secret', String.raw `zoom(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|jwt)`, 'critical', 84),
	    assignmentDetector('pagerduty-assignment', 'PagerDuty Secret', String.raw `pagerduty(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|routing(?:_|-)?key)`, 'critical', 84),
	    assignmentDetector('opsgenie-assignment', 'Opsgenie Secret', String.raw `opsgenie(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('databricks-assignment', 'Databricks Secret', String.raw `databricks(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS})`, 'critical', 84),
	    assignmentDetector('snowflake-assignment', 'Snowflake Secret', String.raw `snowflake(?:_|-)?(?:${API_KEY_WORDS}|${API_TOKEN_WORDS}|${SECRET_WORDS}|private(?:_|-)?key|password)`, 'critical', 84),
	];
	const BROAD_ASSIGNMENT_FAMILIES = [
	    { id: 'api-key', name: 'API Key', pattern: API_KEY_WORDS, severity: 'critical', confidence: 82 },
	    { id: 'token', name: 'Token', pattern: API_TOKEN_WORDS, severity: 'critical', confidence: 82 },
	    { id: 'secret', name: 'Secret', pattern: SECRET_WORDS, severity: 'critical', confidence: 82 },
	    { id: 'password', name: 'Password', pattern: String.raw `password|passwd|pwd|passphrase`, severity: 'critical', confidence: 80 },
	    { id: 'credential', name: 'Credential', pattern: String.raw `credential|credentials|creds`, severity: 'high', confidence: 78 },
	    { id: 'webhook', name: 'Webhook Secret', pattern: String.raw `webhook(?:_|-)?(?:url|secret|token|key)|callback(?:_|-)?secret`, severity: 'high', confidence: 78 },
	    { id: 'signing', name: 'Signing Secret', pattern: String.raw `signing(?:_|-)?(?:secret|key)|signature(?:_|-)?secret|hmac(?:_|-)?key`, severity: 'critical', confidence: 80 },
	    { id: 'connection', name: 'Connection Secret', pattern: String.raw `connection(?:_|-)?(?:string|url|secret)|dsn|database(?:_|-)?url`, severity: 'critical', confidence: 78 },
	];
	const BROAD_PROVIDER_CATALOG = [
	    { id: '1password', name: '1Password', pattern: String.raw `1password|op` },
	    { id: 'ably', name: 'Ably', pattern: String.raw `ably` },
	    { id: 'adyen', name: 'Adyen', pattern: String.raw `adyen` },
	    { id: 'agora', name: 'Agora', pattern: String.raw `agora` },
	    { id: 'airbrake', name: 'Airbrake', pattern: String.raw `airbrake` },
	    { id: 'airtable', name: 'Airtable', pattern: String.raw `airtable` },
	    { id: 'algolia', name: 'Algolia', pattern: String.raw `algolia` },
	    { id: 'alibaba-cloud', name: 'Alibaba Cloud', pattern: String.raw `alibaba(?:_|-)?cloud|aliyun` },
	    { id: 'amplitude', name: 'Amplitude', pattern: String.raw `amplitude` },
	    { id: 'anthropic', name: 'Anthropic', pattern: String.raw `anthropic|claude` },
	    { id: 'apideck', name: 'Apideck', pattern: String.raw `apideck` },
	    { id: 'apify', name: 'Apify', pattern: String.raw `apify` },
	    { id: 'appcenter', name: 'App Center', pattern: String.raw `app(?:_|-)?center` },
	    { id: 'appdynamics', name: 'AppDynamics', pattern: String.raw `appdynamics` },
	    { id: 'apple', name: 'Apple', pattern: String.raw `apple|app(?:_|-)?store(?:_|-)?connect` },
	    { id: 'asana', name: 'Asana', pattern: String.raw `asana` },
	    { id: 'atlassian', name: 'Atlassian', pattern: String.raw `atlassian|jira|confluence` },
	    { id: 'auth0', name: 'Auth0', pattern: String.raw `auth0` },
	    { id: 'aws', name: 'AWS', pattern: String.raw `aws|amazon(?:_|-)?web(?:_|-)?services` },
	    { id: 'azure', name: 'Azure', pattern: String.raw `azure|microsoft(?:_|-)?azure` },
	    { id: 'bamboohr', name: 'BambooHR', pattern: String.raw `bamboohr` },
	    { id: 'bitbucket', name: 'Bitbucket', pattern: String.raw `bitbucket` },
	    { id: 'bitly', name: 'Bitly', pattern: String.raw `bitly` },
	    { id: 'box', name: 'Box', pattern: String.raw `box` },
	    { id: 'braze', name: 'Braze', pattern: String.raw `braze` },
	    { id: 'brevo', name: 'Brevo', pattern: String.raw `brevo|sendinblue` },
	    { id: 'browserstack', name: 'BrowserStack', pattern: String.raw `browserstack` },
	    { id: 'buildkite', name: 'Buildkite', pattern: String.raw `buildkite` },
	    { id: 'calendly', name: 'Calendly', pattern: String.raw `calendly` },
	    { id: 'circleci', name: 'CircleCI', pattern: String.raw `circleci|circle(?:_|-)?ci` },
	    { id: 'clerk', name: 'Clerk', pattern: String.raw `clerk` },
	    { id: 'clickhouse', name: 'ClickHouse', pattern: String.raw `clickhouse` },
	    { id: 'clickup', name: 'ClickUp', pattern: String.raw `clickup` },
	    { id: 'cloudamqp', name: 'CloudAMQP', pattern: String.raw `cloudamqp` },
	    { id: 'cloudflare', name: 'Cloudflare', pattern: String.raw `cloudflare` },
	    { id: 'cloudinary', name: 'Cloudinary', pattern: String.raw `cloudinary` },
	    { id: 'cohere', name: 'Cohere', pattern: String.raw `cohere` },
	    { id: 'coinbase', name: 'Coinbase', pattern: String.raw `coinbase` },
	    { id: 'contentful', name: 'Contentful', pattern: String.raw `contentful` },
	    { id: 'courier', name: 'Courier', pattern: String.raw `courier` },
	    { id: 'databricks', name: 'Databricks', pattern: String.raw `databricks` },
	    { id: 'datadog', name: 'Datadog', pattern: String.raw `datadog` },
	    { id: 'deepgram', name: 'Deepgram', pattern: String.raw `deepgram` },
	    { id: 'digitalocean', name: 'DigitalOcean', pattern: String.raw `digitalocean|do` },
	    { id: 'discord', name: 'Discord', pattern: String.raw `discord` },
	    { id: 'docker', name: 'Docker', pattern: String.raw `docker|dockerhub` },
	    { id: 'doppler', name: 'Doppler', pattern: String.raw `doppler` },
	    { id: 'dropbox', name: 'Dropbox', pattern: String.raw `dropbox` },
	    { id: 'elastic', name: 'Elastic', pattern: String.raw `elastic|elasticsearch|elasticcloud` },
	    { id: 'elevenlabs', name: 'ElevenLabs', pattern: String.raw `elevenlabs|eleven(?:_|-)?labs` },
	    { id: 'fastly', name: 'Fastly', pattern: String.raw `fastly` },
	    { id: 'figma', name: 'Figma', pattern: String.raw `figma` },
	    { id: 'firebase', name: 'Firebase', pattern: String.raw `firebase` },
	    { id: 'flyio', name: 'Fly.io', pattern: String.raw `fly(?:_|-)?io|flyio` },
	    { id: 'freshdesk', name: 'Freshdesk', pattern: String.raw `freshdesk` },
	    { id: 'gcp', name: 'Google Cloud', pattern: String.raw `gcp|google(?:_|-)?cloud|google` },
	    { id: 'ghost', name: 'Ghost', pattern: String.raw `ghost` },
	    { id: 'github', name: 'GitHub', pattern: String.raw `github` },
	    { id: 'gitlab', name: 'GitLab', pattern: String.raw `gitlab` },
	    { id: 'gocardless', name: 'GoCardless', pattern: String.raw `gocardless` },
	    { id: 'grafana', name: 'Grafana', pattern: String.raw `grafana` },
	    { id: 'groq', name: 'Groq', pattern: String.raw `groq` },
	    { id: 'hashicorp', name: 'HashiCorp', pattern: String.raw `hashicorp|vault|terraform` },
	    { id: 'heroku', name: 'Heroku', pattern: String.raw `heroku` },
	    { id: 'honeybadger', name: 'Honeybadger', pattern: String.raw `honeybadger` },
	    { id: 'honeycomb', name: 'Honeycomb', pattern: String.raw `honeycomb` },
	    { id: 'hubspot', name: 'HubSpot', pattern: String.raw `hubspot` },
	    { id: 'huggingface', name: 'Hugging Face', pattern: String.raw `huggingface|hugging(?:_|-)?face|hf` },
	    { id: 'infura', name: 'Infura', pattern: String.raw `infura` },
	    { id: 'influxdb', name: 'InfluxDB', pattern: String.raw `influxdb|influx` },
	    { id: 'intercom', name: 'Intercom', pattern: String.raw `intercom` },
	    { id: 'jenkins', name: 'Jenkins', pattern: String.raw `jenkins` },
	    { id: 'knock', name: 'Knock', pattern: String.raw `knock` },
	    { id: 'launchdarkly', name: 'LaunchDarkly', pattern: String.raw `launchdarkly|launch(?:_|-)?darkly` },
	    { id: 'linear', name: 'Linear', pattern: String.raw `linear` },
	    { id: 'linode', name: 'Linode', pattern: String.raw `linode` },
	    { id: 'lob', name: 'Lob', pattern: String.raw `lob` },
	    { id: 'logdna', name: 'LogDNA', pattern: String.raw `logdna` },
	    { id: 'mailchimp', name: 'Mailchimp', pattern: String.raw `mailchimp` },
	    { id: 'mailgun', name: 'Mailgun', pattern: String.raw `mailgun` },
	    { id: 'mapbox', name: 'Mapbox', pattern: String.raw `mapbox` },
	    { id: 'mattermost', name: 'Mattermost', pattern: String.raw `mattermost` },
	    { id: 'messagebird', name: 'MessageBird', pattern: String.raw `messagebird` },
	    { id: 'mistral', name: 'Mistral', pattern: String.raw `mistral` },
	    { id: 'mixpanel', name: 'Mixpanel', pattern: String.raw `mixpanel` },
	    { id: 'mongodb', name: 'MongoDB', pattern: String.raw `mongodb|mongo` },
	    { id: 'neon', name: 'Neon', pattern: String.raw `neon` },
	    { id: 'netlify', name: 'Netlify', pattern: String.raw `netlify` },
	    { id: 'newrelic', name: 'New Relic', pattern: String.raw `newrelic|new(?:_|-)?relic` },
	    { id: 'ngrok', name: 'ngrok', pattern: String.raw `ngrok` },
	    { id: 'notion', name: 'Notion', pattern: String.raw `notion` },
	    { id: 'npm', name: 'npm', pattern: String.raw `npm` },
	    { id: 'okta', name: 'Okta', pattern: String.raw `okta` },
	    { id: 'oneSignal', name: 'OneSignal', pattern: String.raw `onesignal|one(?:_|-)?signal` },
	    { id: 'openai', name: 'OpenAI', pattern: String.raw `openai` },
	    { id: 'opsgenie', name: 'Opsgenie', pattern: String.raw `opsgenie` },
	    { id: 'oracle-cloud', name: 'Oracle Cloud', pattern: String.raw `oracle(?:_|-)?cloud|oci` },
	    { id: 'pagerduty', name: 'PagerDuty', pattern: String.raw `pagerduty` },
	    { id: 'paypal', name: 'PayPal', pattern: String.raw `paypal` },
	    { id: 'pinecone', name: 'Pinecone', pattern: String.raw `pinecone` },
	    { id: 'plaid', name: 'Plaid', pattern: String.raw `plaid` },
	    { id: 'planetscale', name: 'PlanetScale', pattern: String.raw `planetscale|planet(?:_|-)?scale` },
	    { id: 'posthog', name: 'PostHog', pattern: String.raw `posthog` },
	    { id: 'postman', name: 'Postman', pattern: String.raw `postman` },
	    { id: 'postmark', name: 'Postmark', pattern: String.raw `postmark` },
	    { id: 'pusher', name: 'Pusher', pattern: String.raw `pusher` },
	    { id: 'pypi', name: 'PyPI', pattern: String.raw `pypi` },
	    { id: 'railway', name: 'Railway', pattern: String.raw `railway` },
	    { id: 'rapidapi', name: 'RapidAPI', pattern: String.raw `rapidapi|rapid(?:_|-)?api` },
	    { id: 'razorpay', name: 'Razorpay', pattern: String.raw `razorpay` },
	    { id: 'redis', name: 'Redis', pattern: String.raw `redis|upstash` },
	    { id: 'render', name: 'Render', pattern: String.raw `render` },
	    { id: 'replicate', name: 'Replicate', pattern: String.raw `replicate` },
	    { id: 'rollbar', name: 'Rollbar', pattern: String.raw `rollbar` },
	    { id: 'salesforce', name: 'Salesforce', pattern: String.raw `salesforce` },
	    { id: 'sanity', name: 'Sanity', pattern: String.raw `sanity` },
	    { id: 'saucelabs', name: 'Sauce Labs', pattern: String.raw `saucelabs|sauce(?:_|-)?labs` },
	    { id: 'segment', name: 'Segment', pattern: String.raw `segment` },
	    { id: 'sendbird', name: 'Sendbird', pattern: String.raw `sendbird` },
	    { id: 'sendgrid', name: 'SendGrid', pattern: String.raw `sendgrid` },
	    { id: 'sentry', name: 'Sentry', pattern: String.raw `sentry` },
	    { id: 'shippo', name: 'Shippo', pattern: String.raw `shippo` },
	    { id: 'shopify', name: 'Shopify', pattern: String.raw `shopify` },
	    { id: 'shortcut', name: 'Shortcut', pattern: String.raw `shortcut|clubhouse` },
	    { id: 'slack', name: 'Slack', pattern: String.raw `slack` },
	    { id: 'snowflake', name: 'Snowflake', pattern: String.raw `snowflake` },
	    { id: 'sonarqube', name: 'SonarQube', pattern: String.raw `sonar|sonarqube` },
	    { id: 'splitio', name: 'Split.io', pattern: String.raw `split(?:_|-)?io|splitio` },
	    { id: 'square', name: 'Square', pattern: String.raw `square` },
	    { id: 'stripe', name: 'Stripe', pattern: String.raw `stripe` },
	    { id: 'supabase', name: 'Supabase', pattern: String.raw `supabase` },
	    { id: 'synctera', name: 'Synctera', pattern: String.raw `synctera` },
	    { id: 'telegram', name: 'Telegram', pattern: String.raw `telegram` },
	    { id: 'temporal', name: 'Temporal', pattern: String.raw `temporal` },
	    { id: 'travisci', name: 'Travis CI', pattern: String.raw `travis(?:_|-)?ci|travisci` },
	    { id: 'trello', name: 'Trello', pattern: String.raw `trello` },
	    { id: 'twilio', name: 'Twilio', pattern: String.raw `twilio` },
	    { id: 'typeform', name: 'Typeform', pattern: String.raw `typeform` },
	    { id: 'vercel', name: 'Vercel', pattern: String.raw `vercel` },
	    { id: 'vonage', name: 'Vonage', pattern: String.raw `vonage|nexmo` },
	    { id: 'webflow', name: 'Webflow', pattern: String.raw `webflow` },
	    { id: 'workos', name: 'WorkOS', pattern: String.raw `workos` },
	    { id: 'xai', name: 'xAI', pattern: String.raw `xai|grok` },
	    { id: 'zendesk', name: 'Zendesk', pattern: String.raw `zendesk` },
	    { id: 'zoom', name: 'Zoom', pattern: String.raw `zoom` },
	    { id: 'zuplo', name: 'Zuplo', pattern: String.raw `zuplo` },
	];
	const PROVIDER_CONTEXTS = [
	    { id: 'cloud', name: 'Cloud', pattern: String.raw `cloud` },
	    { id: 'admin', name: 'Admin', pattern: String.raw `admin` },
	    { id: 'app', name: 'App', pattern: String.raw `app|application` },
	    { id: 'service', name: 'Service', pattern: String.raw `service` },
	    { id: 'sdk', name: 'SDK', pattern: String.raw `sdk` },
	    { id: 'webhook', name: 'Webhook', pattern: String.raw `webhook|hook` },
	    { id: 'integration', name: 'Integration', pattern: String.raw `integration|connector` },
	];
	function createContextualProviderCatalog() {
	    return BROAD_PROVIDER_CATALOG.flatMap((provider) => {
	        return PROVIDER_CONTEXTS.map((context) => ({
	            id: `${provider.id}-${context.id}`,
	            name: `${provider.name} ${context.name}`,
	            pattern: String.raw `(?:${provider.pattern})(?:_|-)?(?:${context.pattern})|(?:${context.pattern})(?:_|-)?(?:${provider.pattern})`,
	            severity: provider.severity,
	            confidence: provider.confidence,
	        }));
	    });
	}
	function getUniqueProviderCatalog() {
	    const byId = new Map();
	    [...BROAD_PROVIDER_CATALOG, ...createContextualProviderCatalog()].forEach((provider) => {
	        if (!byId.has(provider.id)) {
	            byId.set(provider.id, provider);
	        }
	    });
	    return Array.from(byId.values());
	}
	const ALL_BROAD_PROVIDER_CATALOG = getUniqueProviderCatalog();
	function createBroadProviderAssignmentDetectors() {
	    return ALL_BROAD_PROVIDER_CATALOG.flatMap((provider) => {
	        return BROAD_ASSIGNMENT_FAMILIES.map((family) => {
	            const names = String.raw `(?:${provider.pattern})(?:_|-)?(?:${family.pattern})|(?:${family.pattern})(?:_|-)?(?:${provider.pattern})`;
	            return assignmentDetector(`${provider.id}-${family.id}`, `${provider.name} ${family.name}`, names, provider.severity || family.severity, provider.confidence || family.confidence);
	        });
	    });
	}
	const BROAD_PROVIDER_ASSIGNMENT_DETECTORS = createBroadProviderAssignmentDetectors();
	const DETECTORS = [
	    {
	        id: 'aws-access-key',
	        name: 'AWS Access Key ID',
	        pattern: /\b(?:A3T[A-Z0-9]|AKIA|ASIA|AGPA|AIDA|AROA|AIPA|ANPA)[A-Z0-9]{16}\b/g,
	        severity: 'critical',
	        confidence: 98,
	    },
	    {
	        id: 'aws-secret-key-assignment',
	        name: 'AWS Secret Access Key',
	        pattern: buildAssignmentPattern(String.raw `aws(?:_|-)?secret(?:_|-)?access(?:_|-)?key|aws(?:_|-)?secret|secret(?:_|-)?access(?:_|-)?key`),
	        severity: 'critical',
	        confidence: 88,
	        validate: isLikelyToken,
	    },
	    {
	        id: 'google-api-key',
	        name: 'Google API Key',
	        pattern: /\bAIza[0-9A-Za-z_-]{35}\b/g,
	        severity: 'high',
	        confidence: 95,
	    },
	    {
	        id: 'google-oauth-client-secret',
	        name: 'Google OAuth Client Secret',
	        pattern: /\bGOCSPX-[0-9A-Za-z_-]{28,64}\b/g,
	        severity: 'high',
	        confidence: 95,
	    },
	    {
	        id: 'github-token',
	        name: 'GitHub Token',
	        pattern: /\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{36,255}\b/g,
	        severity: 'critical',
	        confidence: 98,
	    },
	    {
	        id: 'github-fine-grained-token',
	        name: 'GitHub Fine-Grained Token',
	        pattern: /\bgithub_pat_[A-Za-z0-9_]{22}_[A-Za-z0-9_]{59}\b/g,
	        severity: 'critical',
	        confidence: 98,
	    },
	    {
	        id: 'gitlab-token',
	        name: 'GitLab Personal Access Token',
	        pattern: /\bglpat-[A-Za-z0-9_-]{20,64}\b/g,
	        severity: 'critical',
	        confidence: 96,
	    },
	    {
	        id: 'slack-token',
	        name: 'Slack Token',
	        pattern: /\bxox[baprs]-[A-Za-z0-9-]{10,255}\b/g,
	        severity: 'critical',
	        confidence: 96,
	    },
	    {
	        id: 'slack-webhook',
	        name: 'Slack Webhook URL',
	        pattern: /https:\/\/hooks\.slack\.com\/services\/T[A-Z0-9]{8,12}\/B[A-Z0-9]{8,12}\/[A-Za-z0-9]{20,32}/g,
	        severity: 'critical',
	        confidence: 98,
	    },
	    {
	        id: 'stripe-secret-key',
	        name: 'Stripe Secret Key',
	        pattern: /\b(?:sk|rk)_(?:live|test)_[A-Za-z0-9]{24,99}\b/g,
	        severity: 'critical',
	        confidence: 97,
	    },
	    {
	        id: 'stripe-publishable-key',
	        name: 'Stripe Publishable Key',
	        pattern: /\bpk_(?:live|test)_[A-Za-z0-9]{24,99}\b/g,
	        severity: 'medium',
	        confidence: 88,
	    },
	    {
	        id: 'sendgrid-api-key',
	        name: 'SendGrid API Key',
	        pattern: /\bSG\.[A-Za-z0-9_-]{20,32}\.[A-Za-z0-9_-]{20,96}\b/g,
	        severity: 'critical',
	        confidence: 98,
	    },
	    {
	        id: 'mailgun-api-key',
	        name: 'Mailgun API Key',
	        pattern: /\bkey-[0-9A-Za-z]{32}\b/g,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'twilio-api-key',
	        name: 'Twilio API Key',
	        pattern: /\bSK[0-9a-fA-F]{32}\b/g,
	        severity: 'critical',
	        confidence: 95,
	    },
	    {
	        id: 'square-access-token',
	        name: 'Square Access Token',
	        pattern: /\bsq0atp-[0-9A-Za-z_-]{22,64}\b/g,
	        severity: 'critical',
	        confidence: 95,
	    },
	    {
	        id: 'square-oauth-secret',
	        name: 'Square OAuth Secret',
	        pattern: /\bsq0csp-[0-9A-Za-z_-]{22,64}\b/g,
	        severity: 'critical',
	        confidence: 95,
	    },
	    {
	        id: 'shopify-token',
	        name: 'Shopify Token',
	        pattern: /\bshp(?:at|ca|ss|ua)_[A-Za-z0-9]{32}\b/g,
	        severity: 'critical',
	        confidence: 96,
	    },
	    {
	        id: 'telegram-bot-token',
	        name: 'Telegram Bot Token',
	        pattern: /\b[0-9]{8,10}:[A-Za-z0-9_-]{35}\b/g,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'discord-webhook',
	        name: 'Discord Webhook URL',
	        pattern: /https:\/\/discord(?:app)?\.com\/api\/webhooks\/[0-9]{17,20}\/[A-Za-z0-9_-]{60,100}/g,
	        severity: 'critical',
	        confidence: 96,
	    },
	    {
	        id: 'discord-bot-token',
	        name: 'Discord Bot Token',
	        pattern: /\b[MN][A-Za-z0-9_-]{23}\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{27,39}\b/g,
	        severity: 'critical',
	        confidence: 92,
	    },
	    {
	        id: 'openai-api-key',
	        name: 'OpenAI API Key',
	        pattern: /\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,240}\b/g,
	        severity: 'critical',
	        confidence: 95,
	    },
	    {
	        id: 'anthropic-api-key',
	        name: 'Anthropic API Key',
	        pattern: /\bsk-ant-(?:api|admin)[0-9]{2}-[A-Za-z0-9_-]{20,240}\b/g,
	        severity: 'critical',
	        confidence: 95,
	    },
	    {
	        id: 'groq-api-key',
	        name: 'Groq API Key',
	        pattern: /\bgsk_[A-Za-z0-9]{20,120}\b/g,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'huggingface-token',
	        name: 'Hugging Face Token',
	        pattern: /\bhf_[A-Za-z0-9]{30,120}\b/g,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'replicate-api-token',
	        name: 'Replicate API Token',
	        pattern: /\br8_[A-Za-z0-9]{30,120}\b/g,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'langsmith-api-key',
	        name: 'LangSmith API Key',
	        pattern: /\blsv2_[A-Za-z0-9_]{20,160}\b/g,
	        severity: 'critical',
	        confidence: 92,
	    },
	    {
	        id: 'npm-token',
	        name: 'npm Token',
	        pattern: /\bnpm_[A-Za-z0-9]{36}\b/g,
	        severity: 'critical',
	        confidence: 96,
	    },
	    {
	        id: 'pypi-token',
	        name: 'PyPI Token',
	        pattern: /\bpypi-[A-Za-z0-9_-]{30,240}\b/g,
	        severity: 'critical',
	        confidence: 92,
	    },
	    {
	        id: 'docker-pat',
	        name: 'Docker Personal Access Token',
	        pattern: /\bdckr_pat_[A-Za-z0-9_-]{20,160}\b/g,
	        severity: 'critical',
	        confidence: 96,
	    },
	    {
	        id: 'digitalocean-token',
	        name: 'DigitalOcean Token',
	        pattern: /\bdop_v1_[a-f0-9]{64}\b/gi,
	        severity: 'critical',
	        confidence: 97,
	    },
	    {
	        id: 'netlify-token',
	        name: 'Netlify Token',
	        pattern: /\bnfp_[A-Za-z0-9]{40,120}\b/g,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'vercel-token',
	        name: 'Vercel Token',
	        pattern: /\bvercel_[A-Za-z0-9]{20,160}\b/g,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'linear-api-key',
	        name: 'Linear API Key',
	        pattern: /\blin_api_[A-Za-z0-9]{20,120}\b/g,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'notion-token',
	        name: 'Notion Integration Token',
	        pattern: /\bsecret_[A-Za-z0-9]{30,80}\b/g,
	        severity: 'critical',
	        confidence: 88,
	    },
	    {
	        id: 'airtable-pat',
	        name: 'Airtable Personal Access Token',
	        pattern: /\bpat[A-Za-z0-9]{14}\.[A-Za-z0-9]{40,120}\b/g,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'airtable-legacy-key',
	        name: 'Airtable Legacy API Key',
	        pattern: /\bkey[A-Za-z0-9]{14}\b/g,
	        severity: 'high',
	        confidence: 88,
	    },
	    {
	        id: 'postman-api-key',
	        name: 'Postman API Key',
	        pattern: /\bPMAK-[a-f0-9]{24}-[a-f0-9]{34}\b/gi,
	        severity: 'critical',
	        confidence: 96,
	    },
	    {
	        id: 'hubspot-private-app-token',
	        name: 'HubSpot Private App Token',
	        pattern: /\bpat-[a-z0-9]{2,8}-[A-Za-z0-9-]{30,120}\b/g,
	        severity: 'critical',
	        confidence: 90,
	    },
	    {
	        id: 'mailchimp-api-key',
	        name: 'Mailchimp API Key',
	        pattern: /\b[0-9a-f]{32}-us[0-9]{1,2}\b/gi,
	        severity: 'critical',
	        confidence: 92,
	    },
	    {
	        id: 'mapbox-secret-key',
	        name: 'Mapbox Secret Key',
	        pattern: /\bsk\.[A-Za-z0-9._-]{40,240}\b/g,
	        severity: 'critical',
	        confidence: 90,
	    },
	    {
	        id: 'mapbox-public-key',
	        name: 'Mapbox Public Key',
	        pattern: /\bpk\.[A-Za-z0-9._-]{40,240}\b/g,
	        severity: 'medium',
	        confidence: 82,
	    },
	    {
	        id: 'clerk-secret-key',
	        name: 'Clerk Secret Key',
	        pattern: /\bsk_(?:test|live)_[A-Za-z0-9]{20,120}\b/g,
	        severity: 'critical',
	        confidence: 88,
	    },
	    {
	        id: 'clerk-publishable-key',
	        name: 'Clerk Publishable Key',
	        pattern: /\bpk_(?:test|live)_[A-Za-z0-9]{20,120}\b/g,
	        severity: 'medium',
	        confidence: 82,
	    },
	    {
	        id: 'cloudinary-url',
	        name: 'Cloudinary URL With Secret',
	        pattern: /\bcloudinary:\/\/[A-Za-z0-9_-]{6,64}:[A-Za-z0-9_-]{12,128}@[A-Za-z0-9_-]{2,128}\b/g,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'azure-storage-connection-string',
	        name: 'Azure Storage Connection String',
	        pattern: /\bDefaultEndpointsProtocol=https?;AccountName=[A-Za-z0-9_-]{3,64};AccountKey=[A-Za-z0-9+/=]{40,120}(?:;EndpointSuffix=[A-Za-z0-9.-]+)?/g,
	        severity: 'critical',
	        confidence: 97,
	    },
	    {
	        id: 'azure-sas-token',
	        name: 'Azure SAS Token',
	        pattern: /\bsv=\d{4}-\d{2}-\d{2}&(?:ss|sr)=[A-Za-z]+&[A-Za-z0-9=&%_.:+/-]{20,400}&sig=[A-Za-z0-9%+/=]{20,160}/g,
	        severity: 'critical',
	        confidence: 92,
	    },
	    {
	        id: 'terraform-cloud-token',
	        name: 'Terraform Cloud Token',
	        pattern: /\batlasv1\.[A-Za-z0-9_-]{60,240}\b/g,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'vault-token',
	        name: 'HashiCorp Vault Token',
	        pattern: /\b(?:hvs|hvb)\.[A-Za-z0-9_-]{20,160}\b/g,
	        severity: 'critical',
	        confidence: 96,
	    },
	    {
	        id: 'grafana-service-account-token',
	        name: 'Grafana Service Account Token',
	        pattern: /\bglsa_[A-Za-z0-9_-]{20,240}\b/g,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'grafana-cloud-token',
	        name: 'Grafana Cloud Token',
	        pattern: /\bglc_[A-Za-z0-9+/=]{20,240}\b/g,
	        severity: 'critical',
	        confidence: 92,
	    },
	    {
	        id: 'sonarqube-token',
	        name: 'SonarQube Token',
	        pattern: /\bsqp_[a-f0-9]{40}\b/gi,
	        severity: 'critical',
	        confidence: 94,
	    },
	    {
	        id: 'sentry-token',
	        name: 'Sentry Token',
	        pattern: /\bsntrys_[A-Za-z0-9_-]{20,240}\b/g,
	        severity: 'critical',
	        confidence: 90,
	    },
	    {
	        id: 'dropbox-token',
	        name: 'Dropbox Token',
	        pattern: /\bsl\.[A-Za-z0-9_-]{80,240}\b/g,
	        severity: 'critical',
	        confidence: 92,
	    },
	    {
	        id: 'intercom-token',
	        name: 'Intercom Access Token',
	        pattern: /\bdG9rOj[A-Za-z0-9+/=_-]{20,200}\b/g,
	        severity: 'critical',
	        confidence: 86,
	    },
	    {
	        id: 'oauth-access-token',
	        name: 'OAuth Access Token',
	        pattern: /\bya29\.[A-Za-z0-9_-]{20,240}\b/g,
	        severity: 'critical',
	        confidence: 90,
	    },
	    {
	        id: 'google-service-account-json',
	        name: 'Google Service Account JSON',
	        pattern: /"type"\s*:\s*"service_account"[\s\S]{20,2000}?"private_key"\s*:\s*"-----BEGIN PRIVATE KEY-----[\s\S]{40,5000}?-----END PRIVATE KEY-----\\n"/g,
	        severity: 'critical',
	        confidence: 99,
	    },
	    {
	        id: 'pem-certificate-key-pair',
	        name: 'PEM Key Material',
	        pattern: /-----BEGIN (?:ENCRYPTED |RSA |DSA |EC |OPENSSH |PGP )?(?:PRIVATE KEY|CERTIFICATE REQUEST)-----[\s\S]{40,6000}?-----END (?:ENCRYPTED |RSA |DSA |EC |OPENSSH |PGP )?(?:PRIVATE KEY|CERTIFICATE REQUEST)-----/g,
	        severity: 'critical',
	        confidence: 96,
	    },
	    {
	        id: 'firebase-api-key',
	        name: 'Firebase API Key',
	        pattern: buildAssignmentPattern(String.raw `firebase(?:_|-)?api(?:_|-)?key|apiKey`),
	        severity: 'medium',
	        confidence: 75,
	        validate: (secret, context) => context.toLowerCase().includes('firebase') && isLikelyToken(secret),
	    },
	    {
	        id: 'jwt-token',
	        name: 'JSON Web Token',
	        pattern: /\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g,
	        severity: 'high',
	        confidence: 90,
	    },
	    {
	        id: 'private-key',
	        name: 'Private Key Block',
	        pattern: /-----BEGIN (?:RSA |DSA |EC |OPENSSH |PGP )?PRIVATE KEY-----[\s\S]{40,6000}?-----END (?:RSA |DSA |EC |OPENSSH |PGP )?PRIVATE KEY-----/g,
	        severity: 'critical',
	        confidence: 99,
	    },
	    {
	        id: 'basic-auth-url',
	        name: 'URL With Embedded Credentials',
	        pattern: /\bhttps?:\/\/[A-Za-z0-9._~%+-]{2,64}:[^@\s"'<>]{6,128}@[^\s"'<>]+/g,
	        severity: 'high',
	        confidence: 86,
	    },
	    {
	        id: 'database-url',
	        name: 'Database Connection String',
	        pattern: /\b(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis):\/\/[A-Za-z0-9._~%+-]{2,64}:[^@\s"'<>]{6,128}@[^\s"'<>]+/g,
	        severity: 'critical',
	        confidence: 92,
	    },
	    {
	        id: 'public-config-secret-assignment',
	        name: 'Public Config Secret',
	        pattern: buildConfigAssignmentPattern(String.raw `(?:${PUBLIC_CONFIG_PREFIXES})(?:_|-)?(?:[a-z0-9]+(?:_|-)?){0,8}(?:${PUBLIC_CONFIG_SECRET_WORDS})|(?:${PUBLIC_CONFIG_SECRET_WORDS})`),
	        severity: 'high',
	        confidence: 72,
	        validate: isPotentialConfigSecret,
	    },
	    ...PROVIDER_ASSIGNMENT_DETECTORS,
	    ...BROAD_PROVIDER_ASSIGNMENT_DETECTORS,
	    {
	        id: 'generic-secret-assignment',
	        name: 'Generic Secret Assignment',
	        pattern: buildAssignmentPattern(String.raw `api(?:_|-)?key|access(?:_|-)?token|auth(?:_|-)?token|bearer(?:_|-)?token|client(?:_|-)?secret|refresh(?:_|-)?token|secret(?:_|-)?key|secret|password|passwd|pwd`),
	        severity: 'high',
	        confidence: 68,
	        validate: (secret) => isLikelyToken(secret) && !/^https?:\/\//i.test(secret),
	    },
	];
	function getLineNumber(content, index) {
	    return content.slice(0, index).split('\n').length;
	}
	function cleanContext(context) {
	    return context.replace(/\s+/g, ' ').trim();
	}
	function getContext(content, index, length) {
	    const start = Math.max(0, index - CONTEXT_RADIUS);
	    const end = Math.min(content.length, index + length + CONTEXT_RADIUS);
	    return cleanContext(content.slice(start, end));
	}
	function getSecretFromMatch(match, detector) {
	    if (match.groups?.secret) {
	        return match.groups.secret;
	    }
	    if (detector.secretGroup !== undefined && match[detector.secretGroup]) {
	        return match[detector.secretGroup];
	    }
	    return match[0];
	}
	function severityWeight(severity) {
	    switch (severity) {
	        case 'critical':
	            return 4;
	        case 'high':
	            return 3;
	        case 'medium':
	            return 2;
	        case 'low':
	        default:
	            return 1;
	    }
	}
	function isBetterFinding(candidate, existing) {
	    const candidateSeverity = severityWeight(candidate.severity);
	    const existingSeverity = severityWeight(existing.severity);
	    if (candidateSeverity !== existingSeverity) {
	        return candidateSeverity > existingSeverity;
	    }
	    return candidate.confidence > existing.confidence;
	}
	class SecretScanner {
	    static scan(content) {
	        return this.scanWithCancellation(content, () => false);
	    }
	    static async scanAsync(content, shouldStop) {
	        const findings = new Map();
	        for (const detector of DETECTORS) {
	            if (shouldStop()) {
	                break;
	            }
	            await this.scanDetector(content, detector, findings, shouldStop);
	            await new Promise((resolve) => setTimeout(resolve, 0));
	        }
	        return Array.from(findings.values());
	    }
	    static scanWithCancellation(content, shouldStop) {
	        const findings = new Map();
	        DETECTORS.forEach((detector) => {
	            if (!shouldStop()) {
	                this.scanDetectorSync(content, detector, findings, shouldStop);
	            }
	        });
	        return Array.from(findings.values());
	    }
	    static async scanDetector(content, detector, findings, shouldStop) {
	        detector.pattern.lastIndex = 0;
	        let match;
	        let matchCount = 0;
	        while (!shouldStop() && (match = detector.pattern.exec(content)) !== null) {
	            matchCount += 1;
	            if (match[0].length === 0) {
	                detector.pattern.lastIndex += 1;
	            }
	            if (matchCount % SCAN_YIELD_INTERVAL === 0) {
	                await new Promise((resolve) => setTimeout(resolve, 0));
	            }
	            const secret = getSecretFromMatch(match, detector).trim();
	            const context = getContext(content, match.index, match[0].length);
	            if (!secret || looksLikePlaceholder(secret) || detector.validate?.(secret, context) === false) {
	                continue;
	            }
	            const candidate = {
	                detectorId: detector.id,
	                detectorName: detector.name,
	                secret,
	                context,
	                lineNumber: getLineNumber(content, match.index),
	                confidence: detector.confidence,
	                severity: detector.severity,
	                firstSeenAt: new Date().toISOString(),
	            };
	            const existing = findings.get(secret);
	            if (!existing || isBetterFinding(candidate, existing)) {
	                findings.set(secret, candidate);
	            }
	        }
	    }
	    static scanDetectorSync(content, detector, findings, shouldStop) {
	        detector.pattern.lastIndex = 0;
	        let match;
	        while (!shouldStop() && (match = detector.pattern.exec(content)) !== null) {
	            if (match[0].length === 0) {
	                detector.pattern.lastIndex += 1;
	            }
	            const secret = getSecretFromMatch(match, detector).trim();
	            const context = getContext(content, match.index, match[0].length);
	            if (!secret || looksLikePlaceholder(secret) || detector.validate?.(secret, context) === false) {
	                continue;
	            }
	            const candidate = {
	                detectorId: detector.id,
	                detectorName: detector.name,
	                secret,
	                context,
	                lineNumber: getLineNumber(content, match.index),
	                confidence: detector.confidence,
	                severity: detector.severity,
	                firstSeenAt: new Date().toISOString(),
	            };
	            const existing = findings.get(secret);
	            if (!existing || isBetterFinding(candidate, existing)) {
	                findings.set(secret, candidate);
	            }
	        }
	    }
	}

	const SECRET_SCAN_PROGRESS_KEY = 'secretScanProgress';
	const SECRET_SCAN_STOP_KEY = 'secretScanStopRequested';
	const FETCH_TIMEOUT = 10000;
	const TASK_TIMEOUT = 20000;
	function safeDecodeURIComponent(value) {
	    try {
	        return decodeURIComponent(value);
	    }
	    catch {
	        return value;
	    }
	}
	function pauseForUI() {
	    return new Promise((resolve) => setTimeout(resolve, 0));
	}
	async function fetchTextWithTimeout(url, controller, timeoutMs = FETCH_TIMEOUT) {
	    const timeout = setTimeout(() => controller.abort(), timeoutMs);
	    try {
	        const response = await fetch(url, { signal: controller.signal });
	        return await response.text();
	    }
	    finally {
	        clearTimeout(timeout);
	    }
	}
	function buildScanText(content, capturedURLs) {
	    if (capturedURLs.length === 0) {
	        return content;
	    }
	    return `${content}\n${capturedURLs.join('\n')}`;
	}
	class SecretScanService {
	    running = false;
	    stopRequested = false;
	    activeFetchController = null;
	    storageListenerAttached = false;
	    constructor() {
	        this.attachStopListener();
	    }
	    async scanCapturedURLs() {
	        if (this.running) {
	            return;
	        }
	        this.running = true;
	        this.stopRequested = false;
	        try {
	            const startedAt = new Date().toISOString();
	            await browser.storage.local.set({ [SECRET_SCAN_STOP_KEY]: false });
	            await this.updateProgress({
	                running: true,
	                total: 0,
	                completed: 0,
	                failed: 0,
	                current: 'Starting secret scan',
	                startedAt,
	            });
	            const tasks = await this.getScanTasks();
	            await browser.storage.local.set({
	                'SECRET-PARSER': {},
	                secretCount: 0,
	            });
	            let completed = 0;
	            let failed = 0;
	            await this.updateProgress({
	                running: true,
	                total: tasks.length,
	                completed,
	                failed,
	                current: tasks.length > 0 ? 'Preparing secret scan' : 'No captured URLs to scan',
	                startedAt,
	            });
	            for (const task of tasks) {
	                if (this.stopRequested) {
	                    break;
	                }
	                await this.updateProgress({
	                    running: true,
	                    total: tasks.length,
	                    completed,
	                    failed,
	                    current: task.url,
	                    startedAt,
	                });
	                try {
	                    const content = await this.withTaskTimeout(this.getTaskContent(task));
	                    if (this.stopRequested) {
	                        break;
	                    }
	                    const secrets = await SecretScanner.scanAsync(buildScanText(content, task.capturedURLs), () => this.stopRequested);
	                    if (task.type === 'page') {
	                        await StorageService.savePageSecrets(task.webpageKey, secrets);
	                    }
	                    else {
	                        await StorageService.saveJSFileSecretsForPage(task.webpageKey, task.encodedURL, secrets);
	                    }
	                }
	                catch (error) {
	                    if (this.stopRequested) {
	                        break;
	                    }
	                    failed += 1;
	                    console.error('Secret scan failed for URL:', task.url, error);
	                }
	                if (this.stopRequested) {
	                    break;
	                }
	                completed += 1;
	                await this.updateProgress({
	                    running: true,
	                    total: tasks.length,
	                    completed,
	                    failed,
	                    current: task.url,
	                    startedAt,
	                });
	                await pauseForUI();
	            }
	            await this.updateProgress({
	                running: false,
	                total: tasks.length,
	                completed,
	                failed,
	                current: this.stopRequested ? 'Secret scan stopped' : 'Secret scan complete',
	                startedAt,
	                finishedAt: new Date().toISOString(),
	            });
	        }
	        catch (error) {
	            await this.updateProgress({
	                running: false,
	                total: 0,
	                completed: 0,
	                failed: 0,
	                current: 'Secret scan failed',
	                finishedAt: new Date().toISOString(),
	                error: error instanceof Error ? error.message : String(error),
	            });
	        }
	        finally {
	            this.activeFetchController = null;
	            this.running = false;
	            this.stopRequested = false;
	            await browser.storage.local.set({ [SECRET_SCAN_STOP_KEY]: false });
	        }
	    }
	    stop() {
	        this.stopRequested = true;
	        this.activeFetchController?.abort();
	        browser.storage.local.set({ [SECRET_SCAN_STOP_KEY]: true }).catch((error) => {
	            console.error('Failed to persist secret scan stop request:', error);
	        });
	        if (this.running) {
	            this.updateProgressFromStopRequest().catch((error) => {
	                console.error('Failed to update secret scan stop progress:', error);
	            });
	        }
	    }
	    async getProgress() {
	        const result = await browser.storage.local.get(SECRET_SCAN_PROGRESS_KEY);
	        return result[SECRET_SCAN_PROGRESS_KEY] || {
	            running: false,
	            total: 0,
	            completed: 0,
	            failed: 0,
	            current: '',
	        };
	    }
	    async getScanTasks() {
	        const result = await browser.storage.local.get('URL-PARSER');
	        const urlParser = result['URL-PARSER'] || {};
	        const tasks = [];
	        Object.entries(urlParser).forEach(([webpageKey, value]) => {
	            if (webpageKey === 'current' || typeof value === 'string' || value === undefined) {
	                return;
	            }
	            const item = value;
	            const webpageURL = safeDecodeURIComponent(webpageKey);
	            tasks.push({
	                type: 'page',
	                webpageKey,
	                encodedURL: webpageKey,
	                url: webpageURL,
	                capturedURLs: item.currPage.map((endpoint) => endpoint.url),
	            });
	            Object.entries(item.externalJSFiles).forEach(([encodedJSURL, endpoints]) => {
	                tasks.push({
	                    type: 'javascript',
	                    webpageKey,
	                    encodedURL: encodedJSURL,
	                    url: safeDecodeURIComponent(encodedJSURL),
	                    capturedURLs: endpoints.map((endpoint) => endpoint.url),
	                });
	            });
	        });
	        return tasks;
	    }
	    async getTaskContent(task) {
	        if (task.type === 'page' && task.url === document.location.href) {
	            return document.documentElement?.outerHTML || document.body?.outerHTML || '';
	        }
	        this.activeFetchController = new AbortController();
	        try {
	            return await fetchTextWithTimeout(task.url, this.activeFetchController);
	        }
	        finally {
	            this.activeFetchController = null;
	        }
	    }
	    async updateProgress(progress) {
	        await browser.storage.local.set({ [SECRET_SCAN_PROGRESS_KEY]: progress });
	    }
	    attachStopListener() {
	        if (this.storageListenerAttached) {
	            return;
	        }
	        this.storageListenerAttached = true;
	        browser.storage.onChanged.addListener((changes, areaName) => {
	            if (areaName !== 'local' || !changes[SECRET_SCAN_STOP_KEY]?.newValue) {
	                return;
	            }
	            this.stopRequested = true;
	            this.activeFetchController?.abort();
	        });
	    }
	    async updateProgressFromStopRequest() {
	        const progress = await this.getProgress();
	        await this.updateProgress({
	            ...progress,
	            running: true,
	            current: 'Stopping secret scan',
	        });
	    }
	    async withTaskTimeout(taskPromise) {
	        let timeoutId;
	        const timeoutPromise = new Promise((_, reject) => {
	            timeoutId = setTimeout(() => {
	                this.activeFetchController?.abort();
	                reject(new Error(`Secret scan task timed out after ${TASK_TIMEOUT}ms`));
	            }, TASK_TIMEOUT);
	        });
	        try {
	            return await Promise.race([taskPromise, timeoutPromise]);
	        }
	        finally {
	            if (timeoutId !== undefined) {
	                clearTimeout(timeoutId);
	            }
	        }
	    }
	}

	class Parser {
	    pageParser;
	    jsFileProcessor;
	    secretScanService;
	    progressBar;
	    scriptFiles = [];
	    parsePromise = null;
	    queuedParse = false;
	    constructor() {
	        this.pageParser = new PageParser();
	        this.progressBar = new ProgressBar();
	        this.jsFileProcessor = new JSFileProcessor(this.progressBar); // Pass the instance
	        this.secretScanService = new SecretScanService();
	    }
	    async parseURLs() {
	        if (this.parsePromise) {
	            this.queuedParse = true;
	            await this.parsePromise;
	            if (this.queuedParse) {
	                this.queuedParse = false;
	                return this.parseURLs();
	            }
	            return;
	        }
	        this.parsePromise = this.runParseURLs();
	        try {
	            await this.parsePromise;
	        }
	        finally {
	            this.parsePromise = null;
	        }
	        if (this.queuedParse) {
	            this.queuedParse = false;
	            return this.parseURLs();
	        }
	    }
	    async runParseURLs() {
	        await this.jsFileProcessor.setConcurrentRequests();
	        const host = document.location.hostname;
	        if (await StorageService.isInScope(host)) {
	            if (!shouldCaptureWebpage(document.location.href)) {
	                return;
	            }
	            this.progressBar.update(0, 'Parsing...');
	            try {
	                await this.pageParser.parseCurrentPage();
	                await this.parseExternalFiles();
	                this.progressBar.update(100, 'Done');
	            }
	            catch (error) {
	                console.error("Error during parsing:", error);
	                this.progressBar.update(100, 'Error occurred');
	            }
	            finally {
	                setTimeout(() => this.progressBar.remove(), 2000);
	            }
	        }
	    }
	    async parseExternalFiles() {
	        // Get initial script files
	        this.scriptFiles = this.pageParser.getScriptFiles();
	        // Setup observer for new scripts
	        const observer = this.pageParser.setupScriptObserver((newScripts) => {
	            this.scriptFiles = [...this.scriptFiles, ...newScripts];
	        });
	        try {
	            await this.jsFileProcessor.processBatch(this.scriptFiles);
	        }
	        finally {
	            observer.disconnect();
	        }
	    }
	    async reparse() {
	        this.jsFileProcessor = new JSFileProcessor(this.progressBar); // Pass the existing progressBar instance
	        this.queuedParse = false;
	        return this.parseURLs();
	    }
	    async scanSecrets() {
	        return this.secretScanService.scanCapturedURLs();
	    }
	    stopSecretScan() {
	        this.secretScanService.stop();
	    }
	    async getSecretScanProgress() {
	        return this.secretScanService.getProgress();
	    }
	    static async countURLs() {
	        const result = await browser.storage.local.get('URL-PARSER');
	        const urlParser = result['URL-PARSER'] || {};
	        const currentURL = urlParser.current;
	        if (currentURL && urlParser[currentURL]) {
	            const currentPageData = urlParser[currentURL];
	            const pageURLs = currentPageData.currPage.length;
	            const externalURLs = Object.values(currentPageData.externalJSFiles)
	                .reduce((total, urls) => total + urls.length, 0);
	            return pageURLs + externalURLs;
	        }
	        return 0;
	    }
	    static async countJSFiles() {
	        const scriptTags = document.getElementsByTagName('script');
	        return Array.from(scriptTags).filter(script => script.src).length;
	    }
	}

	let isAutoParserEnabled = false;
	const parser = new Parser();
	let autoParseObserver = null;
	let autoParseTimer = null;
	const AUTO_PARSE_DELAY = 750;
	const PARSER_PROGRESS_ID = 'parsing-progress-container';
	function extractRenderedSourceText() {
	    const preText = document.querySelector('pre')?.textContent || '';
	    const bodyText = document.body?.innerText || '';
	    const documentText = document.documentElement?.textContent || '';
	    const documentMarkup = document.documentElement?.outerHTML || '';
	    return {
	        body: preText || bodyText || documentText || documentMarkup,
	        contentType: document.contentType || '',
	    };
	}
	function scheduleAutoParse(reason) {
	    if (!isAutoParserEnabled) {
	        return;
	    }
	    parser.parseURLs().catch((error) => {
	        console.error(`Auto parser failed during ${reason}:`, error);
	    });
	}
	function queueAutoParse(reason) {
	    if (!isAutoParserEnabled || autoParseTimer) {
	        return;
	    }
	    autoParseTimer = setTimeout(() => {
	        autoParseTimer = null;
	        scheduleAutoParse(reason);
	    }, AUTO_PARSE_DELAY);
	}
	function isParserProgressMutation(mutation) {
	    const target = mutation.target instanceof Element ? mutation.target : mutation.target.parentElement;
	    if (target?.closest(`#${PARSER_PROGRESS_ID}`)) {
	        return true;
	    }
	    const changedNodes = mutation.type === 'childList'
	        ? [...Array.from(mutation.addedNodes), ...Array.from(mutation.removedNodes)]
	        : [];
	    return changedNodes.length > 0 &&
	        changedNodes.every((node) => node instanceof Element && (node.id === PARSER_PROGRESS_ID || Boolean(node.closest(`#${PARSER_PROGRESS_ID}`))));
	}
	function startAutoParseObserver() {
	    if (autoParseObserver || !isAutoParserEnabled || !document.documentElement) {
	        return;
	    }
	    autoParseObserver = new MutationObserver((mutations) => {
	        if (mutations.some((mutation) => !isParserProgressMutation(mutation))) {
	            queueAutoParse('dom-mutation');
	        }
	    });
	    autoParseObserver.observe(document.documentElement, {
	        childList: true,
	        subtree: true,
	        attributes: true,
	        attributeFilter: ['src', 'href', 'action'],
	    });
	}
	function stopAutoParseObserver() {
	    autoParseObserver?.disconnect();
	    autoParseObserver = null;
	    if (autoParseTimer) {
	        clearTimeout(autoParseTimer);
	        autoParseTimer = null;
	    }
	}
	function setAutoParserEnabled(enabled, reason) {
	    isAutoParserEnabled = enabled;
	    if (enabled) {
	        startAutoParseObserver();
	        scheduleAutoParse(reason);
	    }
	    else {
	        stopAutoParseObserver();
	    }
	}
	// Set up message listener for content script
	browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
	    console.log('Content script received message:', message);
	    const typedMessage = message;
	    const typedSendResponse = (response) => sendResponse(response);
	    switch (typedMessage.action) {
	        case 'parseURLs':
	            parser.parseURLs().then(() => typedSendResponse({ success: true }));
	            break;
	        case 'reparse':
	            parser.reparse().then(() => typedSendResponse({ success: true }));
	            break;
	        case 'countURLs':
	            Parser.countURLs().then(count => typedSendResponse({ success: true, count }));
	            break;
	        case 'countJSFiles':
	            Parser.countJSFiles().then(count => typedSendResponse({ success: true, count }));
	            break;
	        case 'scanSecrets':
	            parser.scanSecrets();
	            typedSendResponse({ success: true });
	            break;
	        case 'stopSecretScan':
	            parser.stopSecretScan();
	            typedSendResponse({ success: true });
	            break;
	        case 'getSecretScanProgress':
	            parser.getSecretScanProgress().then(details => typedSendResponse({ success: true, details }));
	            break;
	        case 'getAutoParserState':
	            typedSendResponse({ success: true, state: isAutoParserEnabled });
	            break;
	        case 'setAutoParserState':
	            setAutoParserEnabled(typedMessage.state ?? false, 'toggle');
	            typedSendResponse({ success: true });
	            break;
	        case 'autoParserStateChanged':
	            setAutoParserEnabled(typedMessage.state ?? false, 'state-change');
	            typedSendResponse({ success: true });
	            break;
	        case 'checkContentScriptInjected':
	            typedSendResponse({ success: true });
	            break;
	        case 'extractSourceContent': {
	            const source = extractRenderedSourceText();
	            typedSendResponse({
	                success: Boolean(source.body),
	                body: source.body,
	                headers: {
	                    'content-type': source.contentType,
	                },
	                error: source.body ? undefined : 'No rendered source text found',
	            });
	            break;
	        }
	        case 'clearURLs':
	            browser.storage.local.set({
	                "URL-PARSER": {},
	                "SECRET-PARSER": {},
	                secretCount: 0,
	                secretScanProgress: {
	                    running: false,
	                    total: 0,
	                    completed: 0,
	                    failed: 0,
	                    current: '',
	                }
	            }).then(() => typedSendResponse({ success: true }));
	            break;
	        default:
	            typedSendResponse({ success: false, error: 'Unknown action' });
	    }
	    return true; // Keeps the message channel open for asynchronous responses
	});
	// Initialize as early as possible. Reading storage directly is faster than waiting
	// on a background round-trip during very short redirect documents.
	browser.storage.local.get('autoParserEnabled').then((result) => {
	    setAutoParserEnabled(Boolean(result.autoParserEnabled), 'document-start');
	}).catch(() => {
	    browser.runtime.sendMessage({ action: 'getAutoParserState' }).then((response) => {
	        setAutoParserEnabled(response.state ?? false, 'background-state');
	    });
	});
	browser.storage.onChanged.addListener((changes, areaName) => {
	    if (areaName === 'local' && changes.autoParserEnabled) {
	        setAutoParserEnabled(Boolean(changes.autoParserEnabled.newValue), 'storage-change');
	    }
	});
	if (document.readyState === 'loading') {
	    document.addEventListener('DOMContentLoaded', () => {
	        startAutoParseObserver();
	        scheduleAutoParse('dom-content-loaded');
	    }, { once: true });
	}
	else {
	    startAutoParseObserver();
	    scheduleAutoParse('already-interactive');
	}
	window.addEventListener('load', () => scheduleAutoParse('load'), { once: true });
	window.addEventListener('pageshow', () => scheduleAutoParse('pageshow'), { once: true });
	document.addEventListener('readystatechange', () => {
	    if (document.readyState === 'interactive' || document.readyState === 'complete') {
	        scheduleAutoParse(`ready-state-${document.readyState}`);
	    }
	});
	window.addEventListener('popstate', () => queueAutoParse('history-navigation'));
	window.addEventListener('hashchange', () => queueAutoParse('hash-navigation'));

})();
